import React from 'react';
import { View, StyleSheet } from 'react-native';

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

export function GridRows<T>({ items, columns, renderItem, keyExtractor }: { items: T[]; columns: number; renderItem: (item: T, index: number) => React.ReactNode; keyExtractor: (item: T, index: number) => string }) {
  const rows = chunk(items, columns);
  return (
    <View style={{ marginBottom: 20 }}>
      {rows.map((row, ri) => (
        <View key={ri} style={styles.row}>
          {row.map((item, ci) => {
            const idx = ri * columns + ci;
            return (
              <View key={keyExtractor(item, idx)} style={{ width: `${100 / columns}%` }}>
                {renderItem(item, idx)}
              </View>
            );
          })}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    marginBottom: 10,
  },
});
