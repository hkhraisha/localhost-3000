import React from 'react';
import { Ionicons, MaterialCommunityIcons, FontAwesome5 } from '@expo/vector-icons';

export type IconSet = 'ion' | 'mci' | 'fa5';

export interface IconSpec {
  set: IconSet;
  name: string;
}

interface Props extends IconSpec {
  size?: number;
  color?: string;
}

export function AppIcon({ set, name, size = 18, color = '#171A1E' }: Props) {
  if (set === 'mci') {
    return <MaterialCommunityIcons name={name as any} size={size} color={color} />;
  }
  if (set === 'fa5') {
    return <FontAwesome5 name={name as any} size={size} color={color} />;
  }
  return <Ionicons name={name as any} size={size} color={color} />;
}

// Shared UI icons (nav, buttons, chrome) keyed by the same semantic names used
// throughout the original Tabler-icons based design.
export const UI_ICONS = {
  sparkles: { set: 'ion', name: 'sparkles-outline' } as IconSpec,
  sparklesFilled: { set: 'ion', name: 'sparkles' } as IconSpec,
  shieldCheck: { set: 'ion', name: 'shield-checkmark-outline' } as IconSpec,
  bolt: { set: 'ion', name: 'flash-outline' } as IconSpec,
  thumbUp: { set: 'ion', name: 'thumbs-up-outline' } as IconSpec,
  dots: { set: 'ion', name: 'ellipsis-horizontal' } as IconSpec,
  message2: { set: 'ion', name: 'chatbubble-outline' } as IconSpec,
  targetArrow: { set: 'mci', name: 'target-account' } as IconSpec,
  armchair: { set: 'mci', name: 'sofa-outline' } as IconSpec,
  tag: { set: 'ion', name: 'pricetag-outline' } as IconSpec,
  lock: { set: 'ion', name: 'lock-closed-outline' } as IconSpec,
  brandApple: { set: 'fa5', name: 'apple' } as IconSpec,
  brandGooglePlay: { set: 'fa5', name: 'google-play' } as IconSpec,
  search: { set: 'ion', name: 'search-outline' } as IconSpec,
  microphone: { set: 'ion', name: 'mic-outline' } as IconSpec,
  calendarEvent: { set: 'ion', name: 'calendar-outline' } as IconSpec,
  user: { set: 'ion', name: 'person-outline' } as IconSpec,
  mapPin: { set: 'ion', name: 'location-outline' } as IconSpec,
  chevronLeft: { set: 'ion', name: 'chevron-back' } as IconSpec,
  chevronRight: { set: 'ion', name: 'chevron-forward' } as IconSpec,
  clockBolt: { set: 'mci', name: 'clock-fast' } as IconSpec,
  headset: { set: 'ion', name: 'headset-outline' } as IconSpec,
  plane: { set: 'ion', name: 'airplane-outline' } as IconSpec,
  users: { set: 'ion', name: 'people-outline' } as IconSpec,
  brandVisa: { set: 'fa5', name: 'cc-visa' } as IconSpec,
  brandMastercard: { set: 'fa5', name: 'cc-mastercard' } as IconSpec,
  plus: { set: 'ion', name: 'add-outline' } as IconSpec,
  starFilled: { set: 'ion', name: 'star' } as IconSpec,
  star: { set: 'ion', name: 'star-outline' } as IconSpec,
  trash: { set: 'ion', name: 'trash-outline' } as IconSpec,
  check: { set: 'ion', name: 'checkmark-outline' } as IconSpec,
  phone: { set: 'ion', name: 'call-outline' } as IconSpec,
  messageCircle: { set: 'ion', name: 'chatbubble-ellipses-outline' } as IconSpec,
  car: { set: 'ion', name: 'car-outline' } as IconSpec,
  tool: { set: 'ion', name: 'construct-outline' } as IconSpec,
  moon: { set: 'ion', name: 'moon-outline' } as IconSpec,
  home: { set: 'ion', name: 'home-outline' } as IconSpec,
  gridDots: { set: 'ion', name: 'grid-outline' } as IconSpec,
  calendar: { set: 'ion', name: 'calendar-outline' } as IconSpec,
};
