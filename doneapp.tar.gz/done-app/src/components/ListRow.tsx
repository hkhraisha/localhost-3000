import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { AppIcon, IconSpec } from './Icon';

export function ListRow({ title, subtitle, icon, onPress }: { title: string; subtitle: string; icon: IconSpec; onPress?: () => void }) {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper style={styles.row} onPress={onPress} activeOpacity={onPress ? 0.7 : undefined}>
      <View>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>
      <AppIcon {...icon} size={17} color={colors.textFaint} />
    </Wrapper>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderWidth: 0.5,
    borderColor: colors.border,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
  },
  title: { fontSize: 13, fontWeight: '500', color: colors.ink },
  subtitle: { fontSize: 11, color: colors.textFaint, marginTop: 2 },
});
