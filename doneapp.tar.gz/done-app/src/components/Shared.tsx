import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ViewStyle, StyleProp, TextStyle } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, IconSpec } from './Icon';

export function Wordmark({ size = 16 }: { size?: number }) {
  return <Text style={{ fontFamily: fonts.serif, fontWeight: '700', fontSize: size, letterSpacing: 1.5, color: colors.ink, paddingVertical: 8, paddingBottom: 18 }}>DONE</Text>;
}

export function SectionLabel({ children, style, first }: { children: React.ReactNode; style?: StyleProp<TextStyle>; first?: boolean }) {
  return (
    <Text style={[styles.sectionLabel, { marginTop: first ? 0 : 24 }, style]}>{children}</Text>
  );
}

export function Divider({ style }: { style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.divider, style]} />;
}

export function Card({ children, style, onPress }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper style={[styles.card, style]} onPress={onPress} activeOpacity={onPress ? 0.7 : undefined}>
      {children}
    </Wrapper>
  );
}

export function PrimaryButton({ label, onPress, style }: { label: string; onPress?: () => void; style?: StyleProp<ViewStyle> }) {
  return (
    <TouchableOpacity style={[styles.primaryBtn, style]} onPress={onPress} activeOpacity={0.85}>
      <Text style={styles.primaryBtnLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

export function SecondaryButton({ label, onPress, icon, style }: { label: string; onPress?: () => void; icon?: IconSpec; style?: StyleProp<ViewStyle> }) {
  return (
    <TouchableOpacity style={[styles.secondaryBtn, style]} onPress={onPress} activeOpacity={0.7}>
      {icon ? <AppIcon {...icon} size={15} color={colors.ink} /> : null}
      <Text style={styles.secondaryBtnLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

export function IconTile({ icon, bg, fg, size = 44, iconSize = 18 }: { icon: IconSpec; bg: string; fg: string; size?: number; iconSize?: number }) {
  return (
    <View style={[styles.iconTile, { width: size, height: size, borderRadius: size * 0.27, backgroundColor: bg }]}>
      <AppIcon {...icon} size={iconSize} color={fg} />
    </View>
  );
}

export function ScreenHeader({ title, onBack }: { title: string; onBack?: () => void }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 }}>
      {onBack ? (
        <TouchableOpacity style={styles.backCircle} onPress={onBack}>
          <AppIcon set="ion" name="chevron-back" size={18} color={colors.ink} />
        </TouchableOpacity>
      ) : null}
      <Text style={styles.pageTitle}>{title}</Text>
    </View>
  );
}

export function StarRow({ rating = 5, size = 12 }: { rating?: number; size?: number }) {
  const full = Math.round(rating);
  return (
    <Text style={{ color: colors.gold, fontSize: size }}>
      {'★'.repeat(full)}
      {'☆'.repeat(Math.max(0, 5 - full))}
    </Text>
  );
}

export function Pill({ children, style, textStyle }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; textStyle?: StyleProp<TextStyle> }) {
  return (
    <View style={[styles.pill, style]}>
      <Text style={[styles.pillText, textStyle]}>{children}</Text>
    </View>
  );
}

export function StatusBadge({ label, bg, fg }: { label: string; bg: string; fg: string }) {
  return (
    <View style={{ backgroundColor: bg, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 }}>
      <Text style={{ fontSize: 10, fontWeight: '700', letterSpacing: 0.3, color: fg }}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionLabel: {
    fontSize: 11,
    letterSpacing: 0.5,
    color: colors.textFaint,
    marginBottom: 10,
    textTransform: 'uppercase',
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
    marginVertical: 16,
  },
  card: {
    backgroundColor: colors.white,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
  },
  primaryBtn: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: colors.ink,
  },
  primaryBtnLabel: {
    color: colors.white,
    fontSize: 13,
    fontWeight: '600',
    fontFamily: fonts.sansSemiBold,
  },
  secondaryBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: colors.white,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  secondaryBtnLabel: {
    color: colors.ink,
    fontSize: 13,
    fontWeight: '600',
    fontFamily: fonts.sansSemiBold,
  },
  iconTile: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  backCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.white,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pageTitle: {
    fontFamily: fonts.serif,
    fontWeight: '700',
    fontSize: 19,
    color: colors.ink,
  },
  pill: {
    alignSelf: 'flex-start',
    backgroundColor: colors.goldSoft,
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: 20,
  },
  pillText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
    color: colors.gold,
  },
});
