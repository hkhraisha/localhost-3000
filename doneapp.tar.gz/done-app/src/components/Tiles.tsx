import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { IconTile } from './Shared';
import { AppIcon, IconSpec } from './Icon';

export function CategoryTile({ label, icon, bg, fg, countLabel, onPress }: { label: string; icon: IconSpec; bg: string; fg: string; countLabel?: string; onPress: () => void }) {
  return (
    <TouchableOpacity style={styles.tile} onPress={onPress} activeOpacity={0.7}>
      <IconTile icon={icon} bg={bg} fg={fg} />
      <Text style={styles.tileLabel} numberOfLines={1}>{label}</Text>
      {countLabel ? <Text style={styles.tileCount}>{countLabel}</Text> : null}
    </TouchableOpacity>
  );
}

export function HScrollCard({ title, meta, icon, onPress }: { title: string; meta: string; icon: IconSpec; onPress: () => void }) {
  return (
    <TouchableOpacity style={styles.hCard} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.hCardImage}>
        <AppIcon {...icon} size={22} color={colors.gold} />
      </View>
      <Text style={styles.hCardTitle} numberOfLines={1}>{title}</Text>
      <Text style={styles.hCardMeta}>{meta}</Text>
    </TouchableOpacity>
  );
}

export function FeaturedRow({ title, meta, price, icon, onPress }: { title: string; meta: string; price: string; icon: IconSpec; onPress: () => void }) {
  return (
    <TouchableOpacity style={styles.featuredRow} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.featuredIcon}>
        <AppIcon {...icon} size={20} color={colors.gold} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.featuredTitle} numberOfLines={1}>{title}</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
          <Text style={styles.featuredMeta}>{meta}</Text>
          <Text style={styles.featuredPrice}>{price}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  tile: { alignItems: 'center' },
  tileLabel: { fontSize: 10.5, color: colors.textMuted, marginTop: 6, textAlign: 'center' },
  tileCount: { fontSize: 9, color: colors.textFaint, marginTop: 1, textAlign: 'center' },
  hCard: { width: 150, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 10, marginRight: 10 },
  hCardImage: { width: '100%', height: 70, borderRadius: 8, backgroundColor: colors.goldSoft, marginBottom: 8, alignItems: 'center', justifyContent: 'center' },
  hCardTitle: { fontSize: 13, fontWeight: '600', fontFamily: fonts.sansSemiBold, color: colors.ink },
  hCardMeta: { fontSize: 10.5, color: colors.textFaint, marginTop: 3 },
  featuredRow: { backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 14, marginBottom: 10, flexDirection: 'row', gap: 12 },
  featuredIcon: { width: 52, height: 52, borderRadius: 10, backgroundColor: colors.goldSoft, alignItems: 'center', justifyContent: 'center' },
  featuredTitle: { fontSize: 14, fontWeight: '600', fontFamily: fonts.sansSemiBold, color: colors.ink },
  featuredMeta: { fontSize: 11.5, color: colors.textFaint },
  featuredPrice: { fontFamily: fonts.serif, fontWeight: '700', color: colors.ink, fontSize: 13.5 },
});
