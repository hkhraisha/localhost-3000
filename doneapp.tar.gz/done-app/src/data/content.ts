export const popularProDefs = [
  { key: 'physician', name: 'Dr. Rana Saleh', meta: '★ 5.0 · Physician' },
  { key: 'massage', name: 'Layla H.', meta: '★ 4.9 · Massage' },
  { key: 'electric', name: 'Omar F.', meta: '★ 4.9 · Electrician' },
];

export const featuredDefs = [
  { key: 'physician', title: 'Physician home visit', meta: '60 min · ★ 5.0' },
  { key: 'massage', title: 'Swedish massage, at home', meta: '90 min · ★ 4.9' },
  { key: 'cleaning', title: 'Deep home cleaning', meta: '3 hrs · ★ 4.8' },
];

export const bespokeDefs = [
  { key: 'jet', name: 'Private jet charter', meta: 'By request · Global' },
  { key: 'tailor', name: 'Bespoke tailoring', meta: 'In-home fittings' },
  { key: 'retreat', name: 'Private retreats', meta: 'Curated getaways' },
  { key: 'yacht', name: 'Yacht & villa access', meta: 'Invite-only' },
];

export const exclusiveDefs = [
  { key: 'vipevents', title: 'Sold-out events & reservations', meta: 'Members only' },
  { key: 'gifting', title: 'Personal gifting & sourcing', meta: 'Rare & hard-to-find' },
];

export interface BookingSeed {
  id: string;
  key: string;
  title: string;
  date: string;
  person: string;
  price: string;
  status: string;
  statusBg: string;
  statusFg: string;
}

export const bookingSeeds: { upcoming: BookingSeed[]; past: BookingSeed[] } = {
  upcoming: [
    { id: '#5', key: 'electric', title: 'AC repair — Karim T.', date: 'Today, 2:20 PM', person: 'Karim T.', price: '18.00 JOD', status: 'EN ROUTE', statusBg: '#F3ECDD', statusFg: '#BD9D5F' },
    { id: '#4', key: 'airport', title: 'VIP airport transfer', date: 'May 21, 2026 · 12:52 PM', person: 'James Whitmore', price: '35.00 JOD', status: 'PENDING', statusBg: '#FBEBD2', statusFg: '#C6821F' },
  ],
  past: [
    { id: '#3', key: 'cleaning', title: "Deep cleaning — Rana's Team", date: 'Jul 22', person: "Rana's Team", price: '28.00 JOD', status: '★ 5.0', statusBg: '#E7E9EE', statusFg: '#4D5465' },
    { id: '#2', key: 'massage', title: 'Massage — Layla H.', date: 'Jul 14', person: 'Layla H.', price: '45.00 JOD', status: '★ 4.9', statusBg: '#E7E9EE', statusFg: '#4D5465' },
  ],
};

export const testimonials = [
  { quote: "Booked an electrician at 8pm, someone was at my door by 9. Didn't have to call anyone myself.", author: '— Yasmin, Amman' },
  { quote: 'The AI concierge found me a physician on a Friday night in under 5 minutes. Genuinely impressive.', author: '— Nabil, Amman' },
];

export const howItWorks = [
  { icon: 'message2', title: '1. Tell us what you need', desc: 'Type or speak your request, or browse categories directly.' },
  { icon: 'targetArrow', title: '2. Get matched instantly', desc: 'We match you with a vetted professional and confirm pricing upfront.' },
  { icon: 'armchair', title: '3. Relax while it’s handled', desc: "Track your booking in real time and pay securely once it's done." },
] as const;

export const whyChoose = [
  { icon: 'shieldCheck', title: 'Verified professionals', desc: 'Background-checked' },
  { icon: 'tag', title: 'Transparent pricing', desc: 'No surprise fees' },
  { icon: 'lock', title: 'Secure payments', desc: 'Encrypted checkout' },
  { icon: 'thumbUp', title: 'Satisfaction guaranteed', desc: 'Or we make it right' },
] as const;

export const vipBenefits = [
  { icon: 'clockBolt', title: 'Guaranteed same-day service', desc: 'Priority dispatch ahead of standard bookings.' },
  { icon: 'headset', title: 'Dedicated concierge', desc: 'One point of contact for anything you need arranged.' },
  { icon: 'plane', title: 'Travel and lifestyle', desc: 'Restaurant bookings, gifting, and trip planning.' },
  { icon: 'users', title: 'Family accounts', desc: 'Share priority access across your household.' },
] as const;

export const paymentMethods = [
  { icon: 'brandVisa', label: 'Visa •••• 4021', meta: 'Expires 09/28 · Default' },
  { icon: 'brandMastercard', label: 'Mastercard •••• 7742', meta: 'Expires 03/27' },
];

export const recentSuggestion = {
  quote: 'Would love a way to save a favorite provider and rebook them directly.',
  meta: '— submitted 3 days ago',
};

export const chatSeed = [
  { from: 'ai' as const, text: 'Hi Yasmin. What do you need help with today?' },
  { from: 'user' as const, text: "My AC stopped cooling and it's 38° out" },
  { from: 'ai' as const, text: "That sounds urgent — I've found 3 verified AC technicians near you, all rated 4.8+. The soonest can arrive in 40 minutes. Want me to book them?" },
  { from: 'user' as const, text: 'Yes, book the soonest one' },
  { from: 'ai' as const, text: "Done. Karim T. is on his way, arriving around 2:20 PM. I'll text you when he's close." },
];
