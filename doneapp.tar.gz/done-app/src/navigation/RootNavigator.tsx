import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { RootStackParamList } from './types';
import TabNavigator from './TabNavigator';
import DetailScreen from '../screens/DetailScreen';
import TrackingScreen from '../screens/TrackingScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Tabs" component={TabNavigator} />
      <Stack.Group screenOptions={{ presentation: 'modal', animation: 'slide_from_right' }}>
        <Stack.Screen name="Detail" component={DetailScreen} />
        <Stack.Screen name="Tracking" component={TrackingScreen} />
      </Stack.Group>
    </Stack.Navigator>
  );
}
