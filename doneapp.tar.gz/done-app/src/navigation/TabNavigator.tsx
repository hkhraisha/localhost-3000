import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StyleSheet } from 'react-native';
import { TabParamList } from './types';
import { colors } from '../theme/colors';
import { AppIcon } from '../components/Icon';
import HomeStack from './stacks/HomeStack';
import ServicesStack from './stacks/ServicesStack';
import ConciergeStack from './stacks/ConciergeStack';
import BookingsStack from './stacks/BookingsStack';
import ProfileStack from './stacks/ProfileStack';

const Tab = createBottomTabNavigator<TabParamList>();

const TAB_ICONS: Record<keyof TabParamList, string> = {
  Home: 'home-outline',
  Services: 'grid-outline',
  Concierge: 'sparkles-outline',
  Bookings: 'calendar-outline',
  Profile: 'person-outline',
};

export default function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.gold,
        tabBarInactiveTintColor: colors.textFaint,
        tabBarStyle: styles.tabBar,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ color }) => <AppIcon set="ion" name={TAB_ICONS[route.name as keyof TabParamList]} size={20} color={color} />,
      })}
    >
      <Tab.Screen name="Home" component={HomeStack} />
      <Tab.Screen name="Services" component={ServicesStack} />
      <Tab.Screen name="Concierge" component={ConciergeStack} />
      <Tab.Screen name="Bookings" component={BookingsStack} />
      <Tab.Screen name="Profile" component={ProfileStack} />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    height: 78,
    paddingBottom: 14,
    paddingTop: 8,
    backgroundColor: colors.white,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  tabLabel: {
    fontSize: 9.5,
    fontWeight: '500',
  },
});
