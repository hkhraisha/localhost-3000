import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ConciergeStackParamList } from '../types';
import ConciergeScreen from '../../screens/ConciergeScreen';

const Stack = createNativeStackNavigator<ConciergeStackParamList>();

export default function ConciergeStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ConciergeMain" component={ConciergeScreen} />
    </Stack.Navigator>
  );
}
