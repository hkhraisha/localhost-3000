import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../types';
import ProfileScreen from '../../screens/ProfileScreen';
import PlusScreen from '../../screens/PlusScreen';
import PaymentScreen from '../../screens/PaymentScreen';
import FeedbackScreen from '../../screens/FeedbackScreen';
import ProvidersScreen from '../../screens/ProvidersScreen';

const Stack = createNativeStackNavigator<ProfileStackParamList>();

export default function ProfileStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ProfileMain" component={ProfileScreen} />
      <Stack.Screen name="Plus" component={PlusScreen} />
      <Stack.Screen name="Payment" component={PaymentScreen} />
      <Stack.Screen name="Feedback" component={FeedbackScreen} />
      <Stack.Screen name="Providers" component={ProvidersScreen} />
    </Stack.Navigator>
  );
}
