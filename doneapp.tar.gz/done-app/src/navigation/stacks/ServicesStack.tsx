import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ServicesStackParamList } from '../types';
import ServicesScreen from '../../screens/ServicesScreen';
import PlusScreen from '../../screens/PlusScreen';

const Stack = createNativeStackNavigator<ServicesStackParamList>();

export default function ServicesStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ServicesMain" component={ServicesScreen} />
      <Stack.Screen name="Plus" component={PlusScreen} />
    </Stack.Navigator>
  );
}
