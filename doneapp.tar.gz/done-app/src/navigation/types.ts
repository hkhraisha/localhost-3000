import { BookingSeed } from '../data/content';

export type DetailMode = 'category' | 'service';

export type DetailParams = {
  catKey: string;
  mode: DetailMode;
  serviceName?: string;
};

export type TrackingParams = {
  booking: BookingSeed;
};

export type RootStackParamList = {
  Tabs: undefined;
  Detail: DetailParams;
  Tracking: TrackingParams;
};

export type HomeStackParamList = {
  HomeMain: undefined;
  Plus: undefined;
  Feedback: undefined;
};

export type ServicesStackParamList = {
  ServicesMain: undefined;
  Plus: undefined;
};

export type ConciergeStackParamList = {
  ConciergeMain: undefined;
};

export type BookingsStackParamList = {
  BookingsMain: undefined;
};

export type ProfileStackParamList = {
  ProfileMain: undefined;
  Plus: undefined;
  Payment: undefined;
  Feedback: undefined;
  Providers: undefined;
};

export type TabParamList = {
  Home: undefined;
  Services: undefined;
  Concierge: undefined;
  Bookings: undefined;
  Profile: undefined;
};
