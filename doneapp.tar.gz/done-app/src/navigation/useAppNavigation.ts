import { useNavigation } from '@react-navigation/native';
import { DetailMode } from './types';
import { BookingSeed } from '../data/content';

// Screens live at various nesting depths (tab stacks vs. root stack). React
// Navigation bubbles `navigate` calls up to a parent navigator when the
// current one doesn't own the target route, so a loosely-typed navigation
// object lets any screen reach root-level modals (Detail, Tracking) or
// sibling tabs without threading prop types through every stack.
export function useAppNavigation() {
  const navigation = useNavigation<any>();
  return {
    navigation,
    goTab: (tab: 'Home' | 'Services' | 'Concierge' | 'Bookings' | 'Profile') => navigation.navigate(tab),
    openCategory: (catKey: string) => navigation.navigate('Detail', { catKey, mode: 'category' as DetailMode }),
    openService: (catKey: string, serviceName: string) => navigation.navigate('Detail', { catKey, mode: 'service' as DetailMode, serviceName }),
    openPlus: () => navigation.navigate('Plus'),
    openFeedback: () => navigation.navigate('Feedback'),
    openPayment: () => navigation.navigate('Payment'),
    openProviders: () => navigation.navigate('Providers'),
    openTracking: (booking: BookingSeed) => navigation.navigate('Tracking', { booking }),
    goBack: () => navigation.goBack(),
  };
}
