import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { Card, SectionLabel, StatusBadge, Wordmark } from '../components/Shared';
import { categories } from '../data/categories';
import { useAppState } from '../state/AppState';
import { useAppNavigation } from '../navigation/useAppNavigation';
import { BookingSeed } from '../data/content';

export default function BookingsScreen() {
  const { bookingsUpcoming, bookingsPast } = useAppState();
  const { openCategory, openTracking } = useAppNavigation();

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Wordmark />
      <Text style={styles.title}>Bookings</Text>

      <SectionLabel first>Upcoming</SectionLabel>
      {bookingsUpcoming.map((b) => (
        <BookingCard key={b.id} b={b} onOpen={() => openCategory(b.key)} onTrack={b.status === 'EN ROUTE' ? () => openTracking(b) : undefined} showPerson />
      ))}

      <SectionLabel>Past</SectionLabel>
      {bookingsPast.map((b) => (
        <BookingCard key={b.id} b={b} onOpen={() => openCategory(b.key)} />
      ))}
    </ScrollView>
  );
}

function BookingCard({ b, onOpen, onTrack, showPerson }: { b: BookingSeed; onOpen: () => void; onTrack?: () => void; showPerson?: boolean }) {
  return (
    <Card onPress={onOpen}>
      <View style={styles.cardTopRow}>
        <Text style={styles.idText}>ID: {b.id}</Text>
        <AppIcon {...categories[b.key].icon} size={14} color={colors.textFaint} />
      </View>
      <Text style={styles.cardTitle}>{b.title}</Text>
      <View style={styles.metaRow}>
        <AppIcon {...UI_ICONS.calendarEvent} size={13} color={colors.textFaint} />
        <Text style={styles.metaText}>{b.date}</Text>
      </View>
      {showPerson ? (
        <View style={styles.metaRow}>
          <AppIcon {...UI_ICONS.user} size={13} color={colors.textFaint} />
          <Text style={styles.metaText}>{b.person}</Text>
        </View>
      ) : null}
      <View style={styles.priceRow}>
        <Text style={styles.price}>{b.price}</Text>
        <StatusBadge label={b.status} bg={b.statusBg} fg={b.statusFg} />
      </View>
      {onTrack ? (
        <TouchableOpacity style={styles.trackBtn} onPress={onTrack} activeOpacity={0.85}>
          <AppIcon {...UI_ICONS.mapPin} size={15} color={colors.white} />
          <Text style={styles.trackLabel}>Track live location</Text>
        </TouchableOpacity>
      ) : null}
    </Card>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  title: { fontFamily: fonts.serif, color: colors.ink, fontSize: 19, marginBottom: 14 },
  cardTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  idText: { fontSize: 10.5, color: colors.textFaint },
  cardTitle: { fontSize: 14, fontWeight: '600', fontFamily: fonts.sansSemiBold, color: colors.ink, marginBottom: 4 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 3 },
  metaText: { fontSize: 11.5, color: colors.textFaint },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  price: { fontFamily: fonts.serif, fontWeight: '700', color: colors.ink, fontSize: 14 },
  trackBtn: { marginTop: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10, borderRadius: 9, backgroundColor: colors.ink },
  trackLabel: { color: colors.white, fontSize: 12.5, fontWeight: '600' },
});
