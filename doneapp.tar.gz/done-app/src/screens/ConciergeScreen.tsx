import React, { useRef } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { colors } from '../theme/colors';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { Wordmark } from '../components/Shared';
import { useAppState } from '../state/AppState';

export default function ConciergeScreen() {
  const { messages, chatInput, setChatInput, sendChat } = useAppState();
  const scrollRef = useRef<ScrollView>(null);

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={styles.content}
        onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
      >
        <Wordmark />
        <Text style={styles.title}>AI concierge</Text>

        {messages.map((m, i) => (
          <View
            key={i}
            style={[
              styles.bubble,
              m.from === 'ai' ? styles.bubbleAi : styles.bubbleUser,
            ]}
          >
            <Text style={m.from === 'ai' ? styles.bubbleTextAi : styles.bubbleTextUser}>{m.text}</Text>
          </View>
        ))}
      </ScrollView>

      <View style={styles.inputRow}>
        <AppIcon {...UI_ICONS.microphone} size={16} color={colors.textFaint} />
        <TextInput
          value={chatInput}
          onChangeText={setChatInput}
          onSubmitEditing={sendChat}
          placeholder="Type or speak your request"
          placeholderTextColor={colors.textFaint}
          style={styles.input}
        />
        <TouchableOpacity onPress={sendChat}>
          <Text style={styles.sendLabel}>Send</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 16 },
  title: { fontFamily: 'PlayfairDisplay_700Bold', color: colors.ink, fontSize: 19, marginBottom: 14 },
  bubble: { maxWidth: '80%', paddingVertical: 10, paddingHorizontal: 13, borderRadius: 14, marginBottom: 10 },
  bubbleAi: { backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderBottomLeftRadius: 4, alignSelf: 'flex-start' },
  bubbleUser: { backgroundColor: colors.ink, borderBottomRightRadius: 4, alignSelf: 'flex-end' },
  bubbleTextAi: { fontSize: 13, lineHeight: 19, color: colors.ink },
  bubbleTextUser: { fontSize: 13, lineHeight: 19, color: colors.white },
  inputRow: { flexDirection: 'row', gap: 8, alignItems: 'center', backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, paddingVertical: 10, paddingHorizontal: 14, marginHorizontal: 20, marginBottom: 16 },
  input: { flex: 1, fontSize: 13, color: colors.ink, paddingVertical: 4 },
  sendLabel: { color: colors.gold, fontWeight: '600', fontSize: 12.5 },
});
