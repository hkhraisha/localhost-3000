import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useRoute, RouteProp } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { Divider, StarRow } from '../components/Shared';
import { categories } from '../data/categories';
import { RootStackParamList } from '../navigation/types';
import { useAppNavigation } from '../navigation/useAppNavigation';

type DetailRoute = RouteProp<RootStackParamList, 'Detail'>;

const bullets = [
  { title: 'Verified professional', desc: 'Licensed and background-checked.' },
  { title: 'Fixed, upfront pricing', desc: "No surprises when the job's done." },
  { title: 'Satisfaction guaranteed', desc: 'Not happy? Done makes it right.' },
];

export default function DetailScreen() {
  const route = useRoute<DetailRoute>();
  const { catKey, mode, serviceName } = route.params;
  const { navigation, openService } = useAppNavigation();
  const cat = categories[catKey];

  const title = mode === 'service' && serviceName ? serviceName : cat.label;
  const desc =
    mode === 'service' && serviceName
      ? `Professional ${serviceName.toLowerCase()} through Done, delivered by a vetted ${cat.label.toLowerCase()} specialist with fixed, upfront pricing.`
      : cat.desc;
  const showServicesList = mode === 'category' && cat.services.length > 0;
  const showBullets = mode === 'service' || cat.services.length === 0;

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backCircle} onPress={() => navigation.goBack()}>
          <AppIcon {...UI_ICONS.chevronLeft} size={18} color={colors.ink} />
        </TouchableOpacity>
        {mode === 'service' ? <Text style={styles.subLabel}>{cat.label}</Text> : null}
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.hero}>
          <AppIcon {...cat.icon} size={38} color={colors.gold} />
        </View>
        <Text style={styles.title}>{title}</Text>
        <View style={styles.ratingRow}>
          <StarRow size={13} />
          <Text style={styles.ratingText}>{cat.rating}</Text>
        </View>
        <Divider />
        <Text style={styles.desc}>{desc}</Text>
        <Divider />

        {showServicesList ? (
          <>
            <Text style={styles.sectionLabel}>Services</Text>
            {cat.services.map((svc) => (
              <TouchableOpacity key={svc} style={styles.serviceRow} onPress={() => openService(catKey, svc)} activeOpacity={0.7}>
                <Text style={styles.serviceName}>{svc}</Text>
                <AppIcon {...UI_ICONS.chevronRight} size={16} color={colors.textFaint} />
              </TouchableOpacity>
            ))}
          </>
        ) : null}

        {showBullets ? (
          <>
            {bullets.map((b, i) => (
              <View key={i} style={[styles.bulletRow, i < bullets.length - 1 && styles.bulletBorder]}>
                <AppIcon {...UI_ICONS.check} size={18} color={colors.gold} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.bulletTitle}>{b.title}</Text>
                  <Text style={styles.bulletDesc}>{b.desc}</Text>
                </View>
              </View>
            ))}
          </>
        ) : null}
      </ScrollView>

      <View style={styles.footer}>
        <View>
          <Text style={styles.price}>{cat.price}</Text>
          <Text style={styles.priceCaption}>starting at</Text>
        </View>
        <TouchableOpacity style={styles.bookBtn} activeOpacity={0.85}>
          <Text style={styles.bookLabel}>Book now</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  header: { paddingTop: 54, paddingHorizontal: 20, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
  backCircle: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  subLabel: { fontSize: 11, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: 0.5 },
  content: { paddingHorizontal: 20, paddingBottom: 110 },
  hero: { height: 150, borderRadius: 14, backgroundColor: colors.goldSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  title: { fontFamily: fonts.serif, color: colors.ink, fontSize: 19, fontWeight: '700' },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 },
  ratingText: { fontSize: 12, color: colors.textMuted },
  desc: { fontSize: 13, lineHeight: 21, color: colors.textMuted },
  sectionLabel: { fontSize: 11, letterSpacing: 0.5, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 10 },
  serviceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 14, marginBottom: 8 },
  serviceName: { fontSize: 13.5, color: colors.ink },
  bulletRow: { flexDirection: 'row', gap: 12, alignItems: 'flex-start', paddingVertical: 12 },
  bulletBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  bulletTitle: { fontFamily: fonts.sansSemiBold, fontSize: 13.5, fontWeight: '600', color: colors.ink },
  bulletDesc: { fontSize: 11.5, marginTop: 2, color: colors.textMuted },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: colors.white, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border, paddingHorizontal: 20, paddingTop: 14, paddingBottom: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  price: { fontFamily: fonts.serif, fontWeight: '700', fontSize: 18, color: colors.ink },
  priceCaption: { fontFamily: fonts.sans, fontWeight: '400', fontSize: 10, color: colors.textFaint },
  bookBtn: { backgroundColor: colors.ink, paddingVertical: 12, paddingHorizontal: 26, borderRadius: 10 },
  bookLabel: { color: colors.white, fontSize: 13.5, fontWeight: '600' },
});
