import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { Card, PrimaryButton, SectionLabel, Wordmark } from '../components/Shared';
import { recentSuggestion } from '../data/content';
import { useAppState } from '../state/AppState';

export default function FeedbackScreen() {
  const { feedbackRating, setFeedbackRating, feedbackSubmitted, submitFeedback, suggestions } = useAppState();
  const [text, setText] = useState('');

  const onSubmit = () => {
    submitFeedback(text);
    setText('');
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Wordmark />
      <Text style={styles.title}>Feedback & suggestions</Text>
      <Text style={styles.subtitle}>Tell us what's working and what we could do better.</Text>

      <SectionLabel first>Rate your experience</SectionLabel>
      <View style={styles.starsRow}>
        {[1, 2, 3, 4, 5].map((n) => (
          <TouchableOpacity key={n} onPress={() => setFeedbackRating(n)}>
            <AppIcon {...(n <= feedbackRating ? UI_ICONS.starFilled : UI_ICONS.star)} size={26} color={colors.gold} />
          </TouchableOpacity>
        ))}
      </View>

      <SectionLabel first>Your suggestion</SectionLabel>
      <TextInput
        value={text}
        onChangeText={setText}
        placeholder="What would make Done better for you?"
        placeholderTextColor={colors.textFaint}
        multiline
        style={styles.textarea}
      />

      <PrimaryButton label="Submit feedback" onPress={onSubmit} style={{ marginTop: 16 }} />
      {feedbackSubmitted ? <Text style={styles.thanks}>Thanks — we read every suggestion.</Text> : null}

      <SectionLabel>Recent suggestions</SectionLabel>
      {suggestions.map((s, i) => (
        <Card key={i}>
          <Text style={styles.suggestionText}>"{s.text}"</Text>
          <Text style={styles.suggestionMeta}>— submitted {s.submittedAt}</Text>
        </Card>
      ))}
      <Card>
        <Text style={styles.suggestionText}>"{recentSuggestion.quote}"</Text>
        <Text style={styles.suggestionMeta}>{recentSuggestion.meta}</Text>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  title: { fontFamily: fonts.serif, color: colors.ink, fontSize: 19, marginBottom: 6 },
  subtitle: { fontSize: 12.5, marginBottom: 16, color: colors.textMuted },
  starsRow: { flexDirection: 'row', gap: 8, marginBottom: 18 },
  textarea: { width: '100%', minHeight: 110, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 14, fontSize: 13, color: colors.ink, textAlignVertical: 'top' },
  thanks: { fontSize: 12, color: colors.gold, marginTop: 10, textAlign: 'center' },
  suggestionText: { fontSize: 12.5, lineHeight: 18, color: colors.textMuted },
  suggestionMeta: { fontSize: 10.5, color: colors.textFaint, marginTop: 8 },
});
