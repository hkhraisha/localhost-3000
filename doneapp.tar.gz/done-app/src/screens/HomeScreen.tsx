import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { Card, Divider, PrimaryButton, SecondaryButton, SectionLabel, StarRow } from '../components/Shared';
import { CategoryTile, HScrollCard, FeaturedRow } from '../components/Tiles';
import { GridRows } from '../components/Grid';
import { categories, homeQuickCatDefs } from '../data/categories';
import { popularProDefs, testimonials, howItWorks, whyChoose } from '../data/content';
import { useAppNavigation } from '../navigation/useAppNavigation';

const HOW_IT_WORKS_ICONS = UI_ICONS;

export default function HomeScreen() {
  const { openCategory, openPlus, openFeedback, goTab } = useAppNavigation();

  const quickCatItems = [
    ...homeQuickCatDefs.map((q) => ({ kind: 'cat' as const, ...q, icon: categories[q.key].icon })),
    { kind: 'more' as const, key: 'more', label: 'View all' },
  ];

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.logoRow}>
        <View style={styles.logoBadge}>
          <View style={styles.logoInnerRing}>
            <AppIcon set="ion" name="leaf" size={11} color={colors.gold} />
          </View>
        </View>
        <Text style={styles.wordmark}>DONE</Text>
      </View>

      <Text style={styles.h1}>
        Whatever you need,{'\n'}
        <Text style={{ color: colors.gold }}>done.</Text>
      </Text>
      <Text style={styles.subtitle}>Book vetted professionals for home, beauty, travel and more — in minutes.</Text>

      <View style={styles.searchRow}>
        <AppIcon {...UI_ICONS.sparkles} size={15} color={colors.textFaint} />
        <Text style={styles.searchText}>What do you need today?</Text>
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <AppIcon {...UI_ICONS.shieldCheck} size={17} color={colors.gold} />
          <Text style={styles.statLabel}>Vetted pros</Text>
        </View>
        <View style={styles.statItem}>
          <AppIcon {...UI_ICONS.bolt} size={17} color={colors.gold} />
          <Text style={styles.statLabel}>Book in minutes</Text>
        </View>
        <View style={styles.statItem}>
          <AppIcon {...UI_ICONS.thumbUp} size={17} color={colors.gold} />
          <Text style={styles.statLabel}>Satisfaction guaranteed</Text>
        </View>
      </View>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 18 }}>
        <PrimaryButton label="Browse services" onPress={() => goTab('Services')} />
        <SecondaryButton label="Ask AI concierge" onPress={() => goTab('Concierge')} />
      </View>

      <SectionLabel>What we offer</SectionLabel>
      <GridRows
        items={quickCatItems}
        columns={4}
        keyExtractor={(item) => item.key}
        renderItem={(item) =>
          item.kind === 'cat' ? (
            <CategoryTile label={item.label} icon={item.icon} bg={item.bg} fg={item.fg} onPress={() => openCategory(item.key)} />
          ) : (
            <CategoryTile label="View all" icon={{ set: 'ion', name: 'ellipsis-horizontal' }} bg="#E9E1F5" fg="#7A56B0" onPress={() => goTab('Services')} />
          )
        }
      />

      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionHeaderLabel}>
          Popular right now{'\n'}
          <Text style={styles.sectionHeaderSub}>Most booked this week</Text>
        </Text>
        <Text style={styles.seeAll} onPress={() => goTab('Services')}>See all</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }}>
        {popularProDefs.map((p) => (
          <HScrollCard key={p.key} title={p.name} meta={p.meta} icon={categories[p.key].icon} onPress={() => openCategory(p.key)} />
        ))}
      </ScrollView>

      <TouchableOpacity style={styles.vipCard} onPress={openPlus} activeOpacity={0.85}>
        <View style={styles.vipPill}>
          <Text style={styles.vipPillText}>DONE VIP</Text>
        </View>
        <Text style={styles.vipTitle}>Priority, plus bespoke experiences.</Text>
        <Text style={styles.vipDesc}>Dedicated concierge, same-day guarantees, and curated luxury on request.</Text>
      </TouchableOpacity>

      <SectionLabel>Customers say</SectionLabel>
      {testimonials.map((t, i) => (
        <Card key={i}>
          <StarRow />
          <Text style={styles.quote}>"{t.quote}"</Text>
          <Text style={styles.quoteAuthor}>{t.author}</Text>
        </Card>
      ))}

      <SectionLabel>How Done works</SectionLabel>
      {howItWorks.map((step, i) => (
        <View key={i} style={[styles.stepRow, i < howItWorks.length - 1 && styles.stepRowBorder]}>
          <AppIcon {...(HOW_IT_WORKS_ICONS as any)[step.icon]} size={18} color={colors.gold} />
          <View style={{ flex: 1 }}>
            <Text style={styles.stepTitle}>{step.title}</Text>
            <Text style={styles.stepDesc}>{step.desc}</Text>
          </View>
        </View>
      ))}

      <SectionLabel>Why choose Done</SectionLabel>
      <GridRows
        items={[...whyChoose] as any[]}
        columns={2}
        keyExtractor={(item, i) => `${i}`}
        renderItem={(item: any) => (
          <Card style={{ flexDirection: 'row', gap: 12, marginRight: 6 }}>
            <View style={styles.whyIcon}>
              <AppIcon {...(HOW_IT_WORKS_ICONS as any)[item.icon]} size={18} color={colors.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.whyTitle}>{item.title}</Text>
              <Text style={styles.whyDesc}>{item.desc}</Text>
            </View>
          </Card>
        )}
      />

      <TouchableOpacity style={styles.suggestCard} onPress={openFeedback} activeOpacity={0.85}>
        <View style={styles.suggestPill}>
          <Text style={styles.suggestPillText}>SUGGEST A SERVICE</Text>
        </View>
        <Text style={styles.suggestTitle}>Don't see what you need?</Text>
        <Text style={styles.suggestDesc}>Tell us and we'll try to add it — every suggestion is reviewed by our team.</Text>
      </TouchableOpacity>

      <SectionLabel>Get the app</SectionLabel>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <View style={styles.storeBtn}>
          <AppIcon {...UI_ICONS.brandApple} size={16} color={colors.ink} />
          <Text style={styles.storeBtnLabel}>App Store</Text>
        </View>
        <View style={styles.storeBtn}>
          <AppIcon {...UI_ICONS.brandGooglePlay} size={16} color={colors.ink} />
          <Text style={styles.storeBtnLabel}>Google Play</Text>
        </View>
      </View>

      <View style={styles.footer}>
        <View style={styles.footerLinksRow}>
          <Text style={styles.footerLink} onPress={() => goTab('Services')}>All services</Text>
          <Text style={styles.footerLink}>Company</Text>
          <Text style={styles.footerLink} onPress={openFeedback}>Support</Text>
          <Text style={styles.footerLink}>Careers</Text>
          <Text style={styles.footerLink}>Legal</Text>
        </View>
        <Text style={styles.footerCopy}>© 2026 Done. Consider it done.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8, paddingBottom: 18 },
  logoBadge: { width: 30, height: 30, borderRadius: 8, backgroundColor: colors.ink, alignItems: 'center', justifyContent: 'center' },
  logoInnerRing: { width: 15, height: 15, borderRadius: 8, borderWidth: 1.2, borderColor: colors.gold, alignItems: 'center', justifyContent: 'center' },
  wordmark: { fontFamily: fonts.serif, fontWeight: '700', fontSize: 19, letterSpacing: 1.5, color: colors.ink },
  h1: { fontFamily: fonts.serif, color: colors.ink, fontSize: 26, lineHeight: 33, fontWeight: '700' },
  subtitle: { color: colors.textMuted, marginTop: 8, fontSize: 13.5, lineHeight: 20 },
  searchRow: { marginTop: 16, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, paddingVertical: 12, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 8 },
  searchText: { fontSize: 13, color: colors.textFaint },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 16, gap: 6 },
  statItem: { flex: 1, alignItems: 'center' },
  statLabel: { fontSize: 10.5, color: colors.textMuted, marginTop: 4, textAlign: 'center' },
  sectionHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 24, marginBottom: 10 },
  sectionHeaderLabel: { fontSize: 11, letterSpacing: 0.5, color: colors.textFaint, textTransform: 'uppercase' },
  sectionHeaderSub: { textTransform: 'none', fontSize: 11, color: colors.textFaint },
  seeAll: { color: colors.gold, fontWeight: '600', fontSize: 11 },
  vipCard: { marginTop: 22, backgroundColor: colors.ink, borderRadius: 14, padding: 18 },
  vipPill: { alignSelf: 'flex-start', backgroundColor: colors.gold, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 20 },
  vipPillText: { color: colors.ink, fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
  vipTitle: { color: colors.white, fontSize: 16, marginTop: 10, fontFamily: fonts.serif, fontWeight: '700' },
  vipDesc: { color: colors.vipSubtext, fontSize: 11.5, marginTop: 4 },
  quote: { fontSize: 12.5, marginTop: 6, lineHeight: 18, color: colors.textMuted },
  quoteAuthor: { fontSize: 10.5, color: colors.textFaint, marginTop: 8 },
  stepRow: { flexDirection: 'row', gap: 12, alignItems: 'flex-start', paddingVertical: 12 },
  stepRowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  stepTitle: { fontFamily: fonts.sansSemiBold, fontSize: 13.5, fontWeight: '600', color: colors.ink },
  stepDesc: { fontSize: 11.5, marginTop: 2, color: colors.textMuted },
  whyIcon: { width: 40, height: 40, borderRadius: 10, backgroundColor: colors.goldSoft, alignItems: 'center', justifyContent: 'center' },
  whyTitle: { fontFamily: fonts.sansSemiBold, fontSize: 13, fontWeight: '600', color: colors.ink },
  whyDesc: { fontSize: 11, color: colors.textFaint, marginTop: 4 },
  suggestCard: { marginTop: 22, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 14, padding: 18 },
  suggestPill: { alignSelf: 'flex-start', backgroundColor: colors.goldSoft, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 20 },
  suggestPillText: { color: colors.gold, fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
  suggestTitle: { color: colors.ink, fontSize: 16, marginTop: 10, fontFamily: fonts.serif, fontWeight: '700' },
  suggestDesc: { color: colors.textMuted, fontSize: 11.5, marginTop: 4 },
  storeBtn: { flex: 1, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6, paddingVertical: 12, borderRadius: 10, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border },
  storeBtnLabel: { fontSize: 13, fontWeight: '600', color: colors.ink },
  footer: { marginTop: 28, paddingTop: 18, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  footerLinksRow: { flexDirection: 'row', justifyContent: 'space-between' },
  footerLink: { color: colors.ink, fontWeight: '600', fontSize: 11.5 },
  footerCopy: { marginTop: 10, fontSize: 11, color: colors.textFaint },
});
