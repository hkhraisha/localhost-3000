import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { SectionLabel, Wordmark } from '../components/Shared';
import { ListRow } from '../components/ListRow';
import { paymentMethods } from '../data/content';

export default function PaymentScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Wordmark />
      <Text style={styles.title}>Payment methods</Text>

      {paymentMethods.map((m, i) => (
        <View key={i} style={styles.methodRow}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <AppIcon {...(UI_ICONS as any)[m.icon]} size={24} color={colors.ink} />
            <View>
              <Text style={styles.methodLabel}>{m.label}</Text>
              <Text style={styles.methodMeta}>{m.meta}</Text>
            </View>
          </View>
          <AppIcon {...UI_ICONS.dots} size={18} color={colors.textFaint} />
        </View>
      ))}

      <TouchableOpacity style={styles.addRow} activeOpacity={0.7}>
        <AppIcon {...UI_ICONS.plus} size={16} color={colors.textFaint} />
        <Text style={styles.addLabel}>Add payment method</Text>
      </TouchableOpacity>

      <SectionLabel>Billing</SectionLabel>
      <ListRow title="Billing history" subtitle="View past invoices" icon={UI_ICONS.chevronRight} />
      <ListRow title="Promo codes" subtitle="Add a code to your account" icon={UI_ICONS.chevronRight} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  title: { fontFamily: fonts.serif, color: colors.ink, fontSize: 19, marginBottom: 14 },
  methodRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 14, marginBottom: 10 },
  methodLabel: { fontSize: 13, fontWeight: '500', color: colors.ink },
  methodMeta: { fontSize: 11, color: colors.textFaint, marginTop: 2 },
  addRow: { marginTop: 8, justifyContent: 'center', flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, paddingVertical: 12, paddingHorizontal: 14 },
  addLabel: { fontSize: 13, color: colors.textFaint },
});
