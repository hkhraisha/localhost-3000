import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { PrimaryButton, SectionLabel, Wordmark } from '../components/Shared';
import { HScrollCard, FeaturedRow } from '../components/Tiles';
import { categories } from '../data/categories';
import { bespokeDefs, exclusiveDefs, vipBenefits } from '../data/content';
import { useAppNavigation } from '../navigation/useAppNavigation';

export default function PlusScreen() {
  const { openCategory } = useAppNavigation();

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Wordmark />

      <View style={styles.hero}>
        <View style={styles.pill}>
          <Text style={styles.pillText}>DONE VIP</Text>
        </View>
        <Text style={styles.heroTitle}>Priority, on everything — plus a world of bespoke.</Text>
        <Text style={styles.heroDesc}>A dedicated concierge, guaranteed response times, and curated luxury experiences beyond the everyday.</Text>
      </View>

      {vipBenefits.map((b, i) => (
        <View key={i} style={[styles.benefitRow, i < vipBenefits.length - 1 && styles.benefitBorder]}>
          <AppIcon {...(UI_ICONS as any)[b.icon]} size={18} color={colors.gold} />
          <View style={{ flex: 1 }}>
            <Text style={styles.benefitTitle}>{b.title}</Text>
            <Text style={styles.benefitDesc}>{b.desc}</Text>
          </View>
        </View>
      ))}

      <SectionLabel>Bespoke experiences</SectionLabel>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {bespokeDefs.map((b) => (
          <HScrollCard key={b.key} title={b.name} meta={b.meta} icon={categories[b.key].icon} onPress={() => openCategory(b.key)} />
        ))}
      </ScrollView>

      <SectionLabel>Exclusive access</SectionLabel>
      {exclusiveDefs.map((f) => (
        <FeaturedRow key={f.key} title={f.title} meta={f.meta} price={categories[f.key].price} icon={categories[f.key].icon} onPress={() => openCategory(f.key)} />
      ))}

      <PrimaryButton label="Upgrade to Done VIP — 15 JOD/mo" style={{ marginTop: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  hero: { backgroundColor: colors.ink, borderRadius: 16, padding: 22, alignItems: 'center', marginBottom: 20 },
  pill: { backgroundColor: colors.gold, paddingHorizontal: 11, paddingVertical: 4, borderRadius: 20 },
  pillText: { color: colors.ink, fontSize: 10.5, fontWeight: '700', letterSpacing: 0.5 },
  heroTitle: { color: colors.white, fontSize: 20, marginTop: 12, fontFamily: fonts.serif, fontWeight: '700', textAlign: 'center' },
  heroDesc: { color: colors.vipSubtext, fontSize: 12, marginTop: 6, textAlign: 'center' },
  benefitRow: { flexDirection: 'row', gap: 12, alignItems: 'flex-start', paddingVertical: 12 },
  benefitBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  benefitTitle: { fontFamily: fonts.sansSemiBold, fontSize: 13.5, fontWeight: '600', color: colors.ink },
  benefitDesc: { fontSize: 11.5, marginTop: 2, color: colors.textMuted },
});
