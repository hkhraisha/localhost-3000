import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { UI_ICONS } from '../components/Icon';
import { SectionLabel, Wordmark } from '../components/Shared';
import { ListRow } from '../components/ListRow';
import { useAppNavigation } from '../navigation/useAppNavigation';

export default function ProfileScreen() {
  const { openPlus, openFeedback, openProviders, openPayment } = useAppNavigation();

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Wordmark />

      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Text style={styles.avatarLabel}>Y</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>Yasmin Adel</Text>
          <Text style={styles.email}>yasmin.adel@example.com</Text>
        </View>
        <TouchableOpacity style={styles.editBtn}>
          <Text style={styles.editLabel}>Edit</Text>
        </TouchableOpacity>
      </View>

      <SectionLabel first>Preferences</SectionLabel>
      <ListRow title="Appearance" subtitle="Toggle between light and dark mode" icon={UI_ICONS.moon} />
      <ListRow title="Language" subtitle="English" icon={UI_ICONS.chevronRight} />
      <ListRow title="Payment methods" subtitle="Visa •••• 4021" icon={UI_ICONS.chevronRight} onPress={openPayment} />

      <SectionLabel>Account</SectionLabel>
      <ListRow title="Done VIP" subtitle="Not subscribed" icon={UI_ICONS.chevronRight} onPress={openPlus} />
      <ListRow title="Feedback & suggestions" subtitle="Share an idea or rate the app" icon={UI_ICONS.chevronRight} onPress={openFeedback} />
      <ListRow title="Service providers" subtitle="Add or manage professionals" icon={UI_ICONS.chevronRight} onPress={openProviders} />
      <ListRow title="Support" subtitle="Get help with a booking" icon={UI_ICONS.chevronRight} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  profileCard: { backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 16, flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 18 },
  avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.goldSoft, alignItems: 'center', justifyContent: 'center' },
  avatarLabel: { color: colors.gold, fontWeight: '700', fontFamily: fonts.serif, fontSize: 18 },
  name: { fontFamily: fonts.sansSemiBold, fontSize: 15, fontWeight: '600', color: colors.ink },
  email: { fontSize: 11.5, color: colors.textMuted, marginTop: 2 },
  editBtn: { backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 8, paddingVertical: 7, paddingHorizontal: 14 },
  editLabel: { fontSize: 12, fontWeight: '600', color: colors.ink },
});
