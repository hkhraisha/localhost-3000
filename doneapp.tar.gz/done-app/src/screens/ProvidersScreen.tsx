import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { PrimaryButton, ScreenHeader, SectionLabel, Wordmark } from '../components/Shared';
import { categories, categoryColor } from '../data/categories';
import { useAppState } from '../state/AppState';
import { useAppNavigation } from '../navigation/useAppNavigation';

const categoryOptions = Object.keys(categories).map((key) => ({ key, label: categories[key].label }));

export default function ProvidersScreen() {
  const { providers, addProvider, removeProvider } = useAppState();
  const { goBack } = useAppNavigation();

  const [name, setName] = useState('');
  const [category, setCategory] = useState('cleaning');
  const [phone, setPhone] = useState('');
  const [rate, setRate] = useState('');
  const [bio, setBio] = useState('');
  const [error, setError] = useState('');

  const onSubmit = () => {
    const err = addProvider({ name, category, phone, rate, bio });
    if (err) {
      setError(err);
      return;
    }
    setError('');
    setName('');
    setPhone('');
    setRate('');
    setBio('');
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Wordmark />
      <ScreenHeader title="Service providers" onBack={goBack} />

      <View style={styles.formCard}>
        <SectionLabel first>Add a provider</SectionLabel>
        <View style={{ gap: 10 }}>
          <TextInput value={name} onChangeText={(v) => { setName(v); setError(''); }} placeholder="Full name" placeholderTextColor={colors.textFaint} style={styles.input} />
          <View style={styles.pickerWrap}>
            <Picker selectedValue={category} onValueChange={(v) => setCategory(String(v))} style={styles.picker}>
              {categoryOptions.map((opt) => (
                <Picker.Item key={opt.key} value={opt.key} label={opt.label} />
              ))}
            </Picker>
          </View>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <TextInput value={phone} onChangeText={(v) => { setPhone(v); setError(''); }} placeholder="Phone number" placeholderTextColor={colors.textFaint} style={[styles.input, { flex: 1 }]} keyboardType="phone-pad" />
            <TextInput value={rate} onChangeText={(v) => { setRate(v); setError(''); }} placeholder="Rate (JOD)" placeholderTextColor={colors.textFaint} style={[styles.input, { width: 110 }]} keyboardType="numeric" />
          </View>
          <TextInput value={bio} onChangeText={setBio} placeholder="Short bio / specialties" placeholderTextColor={colors.textFaint} multiline style={styles.textarea} />
          <PrimaryButton label="Add provider" onPress={onSubmit} />
          {error ? <Text style={styles.error}>{error}</Text> : null}
        </View>
      </View>

      <SectionLabel first>Your providers ({providers.length})</SectionLabel>
      {providers.map((p) => {
        const { bg, fg } = categoryColor(p.category);
        return (
          <View key={p.id} style={styles.providerCard}>
            <View style={[styles.providerIcon, { backgroundColor: bg }]}>
              <AppIcon {...categories[p.category].icon} size={18} color={fg} />
            </View>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Text style={styles.providerName}>{p.name}</Text>
                <TouchableOpacity onPress={() => removeProvider(p.id)}>
                  <AppIcon {...UI_ICONS.trash} size={16} color={colors.textFaint} />
                </TouchableOpacity>
              </View>
              <Text style={styles.providerMeta}>{categories[p.category].label} · {p.phone}</Text>
              {p.bio ? <Text style={styles.providerBio}>{p.bio}</Text> : null}
              <Text style={styles.providerRate}>{p.rate} JOD</Text>
            </View>
          </View>
        );
      })}
      {providers.length === 0 ? <Text style={styles.empty}>No providers added yet.</Text> : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  formCard: { backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 14, padding: 16, marginBottom: 20 },
  input: { backgroundColor: colors.appBg, borderWidth: 0.5, borderColor: colors.border, borderRadius: 10, paddingVertical: 11, paddingHorizontal: 13, fontSize: 13, color: colors.ink },
  pickerWrap: { backgroundColor: colors.appBg, borderWidth: 0.5, borderColor: colors.border, borderRadius: 10, overflow: 'hidden' },
  picker: { color: colors.ink },
  textarea: { backgroundColor: colors.appBg, borderWidth: 0.5, borderColor: colors.border, borderRadius: 10, padding: 13, fontSize: 13, color: colors.ink, minHeight: 70, textAlignVertical: 'top' },
  error: { fontSize: 11.5, color: colors.error, textAlign: 'center' },
  providerCard: { backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 14, marginBottom: 10, flexDirection: 'row', gap: 12 },
  providerIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  providerName: { fontFamily: fonts.sansSemiBold, fontSize: 14, fontWeight: '600', color: colors.ink },
  providerMeta: { fontSize: 11.5, color: colors.textFaint, marginTop: 3 },
  providerBio: { fontSize: 11.5, color: colors.textMuted, marginTop: 4 },
  providerRate: { fontFamily: fonts.serif, fontWeight: '700', color: colors.ink, fontSize: 13, marginTop: 6 },
  empty: { textAlign: 'center', paddingVertical: 30, color: colors.textFaint, fontSize: 12.5 },
});
