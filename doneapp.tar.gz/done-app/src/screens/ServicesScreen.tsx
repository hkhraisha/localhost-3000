import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { SectionLabel, Wordmark } from '../components/Shared';
import { CategoryTile, FeaturedRow } from '../components/Tiles';
import { GridRows } from '../components/Grid';
import { categories, categoryGroups } from '../data/categories';
import { featuredDefs } from '../data/content';
import { useAppNavigation } from '../navigation/useAppNavigation';

export default function ServicesScreen() {
  const { openCategory, openPlus } = useAppNavigation();
  const [groupKey, setGroupKey] = useState(categoryGroups[0].key);
  const activeGroup = categoryGroups.find((g) => g.key === groupKey)!;
  const showLuxuryTile = groupKey === 'travel';

  const gridItems: { key: string; label: string; icon: any; bg: string; fg: string; countLabel: string; isLuxury?: boolean }[] = [
    ...activeGroup.ids.map((id) => ({
      key: id,
      label: categories[id].label,
      icon: categories[id].icon,
      bg: categories[id].bg ?? '#E7E9EE',
      fg: categories[id].fg ?? '#4D5465',
      countLabel: `${categories[id].services.length} services`,
    })),
    ...(showLuxuryTile ? [{ key: 'luxury', label: 'Luxury & VIP', icon: UI_ICONS.sparkles, bg: '#F3ECDD', fg: colors.gold, countLabel: '18 services', isLuxury: true }] : []),
  ];

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Wordmark />
      <Text style={styles.title}>Services</Text>

      <View style={styles.searchRow}>
        <AppIcon {...UI_ICONS.search} size={15} color={colors.textFaint} />
        <Text style={styles.searchText}>Search services</Text>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsScroll} contentContainerStyle={{ gap: 8 }}>
        {categoryGroups.map((g) => {
          const active = g.key === groupKey;
          return (
            <TouchableOpacity
              key={g.key}
              style={[styles.tab, { backgroundColor: active ? colors.ink : colors.white, borderColor: active ? colors.ink : colors.border }]}
              onPress={() => setGroupKey(g.key)}
            >
              <Text style={{ color: active ? colors.white : colors.textMuted, fontSize: 12.5, fontWeight: '600' }}>{g.label}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <GridRows
        items={gridItems}
        columns={4}
        keyExtractor={(item) => item.key}
        renderItem={(item) => (
          <CategoryTile
            label={item.label}
            icon={item.icon}
            bg={item.bg}
            fg={item.fg}
            countLabel={item.countLabel}
            onPress={() => (item.isLuxury ? openPlus() : openCategory(item.key))}
          />
        )}
      />

      <SectionLabel>Featured this week</SectionLabel>
      {featuredDefs.map((f) => (
        <FeaturedRow
          key={f.key}
          title={f.title}
          meta={f.meta}
          price={categories[f.key].price}
          icon={categories[f.key].icon}
          onPress={() => openCategory(f.key)}
        />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  title: { fontFamily: 'PlayfairDisplay_700Bold', color: colors.ink, fontSize: 19, marginBottom: 14 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 10, paddingVertical: 10, paddingHorizontal: 12, marginBottom: 16 },
  searchText: { fontSize: 13, color: colors.textFaint },
  tabsScroll: { marginBottom: 18 },
  tab: { paddingVertical: 9, paddingHorizontal: 15, borderRadius: 20, borderWidth: 0.5, marginRight: 8 },
});
