import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useRoute, RouteProp } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Path } from 'react-native-svg';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { AppIcon, UI_ICONS } from '../components/Icon';
import { RootStackParamList } from '../navigation/types';
import { useAppState } from '../state/AppState';
import { useAppNavigation } from '../navigation/useAppNavigation';

type TrackingRoute = RouteProp<RootStackParamList, 'Tracking'>;

export default function TrackingScreen() {
  const route = useRoute<TrackingRoute>();
  const { booking } = route.params;
  const { navigation } = useAppNavigation();
  const { locationSharing, toggleLocationSharing } = useAppState();

  const initial = (booking.person || '?').charAt(0);

  return (
    <View style={styles.screen}>
      <View style={styles.mapArea}>
        <LinearGradient colors={['#DCE7DA', '#EAE6D8']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
        <Svg viewBox="0 0 390 340" style={StyleSheet.absoluteFill}>
          <Path d="M0 60 L390 90" stroke="#C7CDC0" strokeWidth={10} fill="none" />
          <Path d="M40 0 L70 340" stroke="#C7CDC0" strokeWidth={8} fill="none" />
          <Path d="M0 220 L390 260" stroke="#C7CDC0" strokeWidth={10} fill="none" />
          <Path d="M260 0 L300 340" stroke="#C7CDC0" strokeWidth={6} fill="none" />
        </Svg>
        <View style={[styles.userPin]} />
        <View style={[styles.workerPin]}>
          <AppIcon {...UI_ICONS.tool} size={16} color={colors.white} />
        </View>
        <View style={styles.mapTopRow}>
          <TouchableOpacity style={styles.mapBackBtn} onPress={() => navigation.goBack()}>
            <AppIcon {...UI_ICONS.chevronLeft} size={18} color={colors.ink} />
          </TouchableOpacity>
          <View style={styles.etaPill}>
            <Text style={styles.etaLabel}>Arriving in 18 min</Text>
          </View>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.personRow}>
          <View style={styles.avatar}>
            <Text style={styles.avatarLabel}>{initial}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.personName}>{booking.person}</Text>
            <Text style={styles.personMeta}>{booking.title} · ★ 4.9</Text>
          </View>
          <TouchableOpacity style={styles.callBtn}>
            <AppIcon {...UI_ICONS.phone} size={17} color={colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.msgBtn}>
            <AppIcon {...UI_ICONS.messageCircle} size={17} color={colors.ink} />
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionLabel}>Your location</Text>
        <View style={styles.locationCard}>
          <View style={styles.addressRow}>
            <AppIcon {...UI_ICONS.mapPin} size={16} color={colors.gold} />
            <Text style={styles.addressText}>Al Rainbow St, Jabal Amman, Amman</Text>
          </View>
          <View style={styles.shareRow}>
            <Text style={styles.shareLabel}>Live share with {booking.person}</Text>
            <TouchableOpacity
              style={[styles.toggleTrack, { backgroundColor: locationSharing ? colors.gold : colors.border }]}
              onPress={toggleLocationSharing}
              activeOpacity={0.85}
            >
              <View style={[styles.toggleThumb, { left: locationSharing ? 21 : 3 }]} />
            </TouchableOpacity>
          </View>
          {locationSharing ? (
            <Text style={styles.sharingNote}>Location shared — {booking.person} can see your pin update in real time.</Text>
          ) : null}
        </View>

        <Text style={styles.sectionLabel}>Trip details</Text>
        <View style={[styles.tripRow, styles.tripBorder]}>
          <AppIcon {...UI_ICONS.car} size={18} color={colors.gold} />
          <View style={{ flex: 1 }}>
            <Text style={styles.tripTitle}>3.2 km away</Text>
            <Text style={styles.tripDesc}>Traveling by car, live GPS tracked.</Text>
          </View>
        </View>
        <View style={styles.tripRow}>
          <AppIcon {...UI_ICONS.shieldCheck} size={18} color={colors.gold} />
          <View style={{ flex: 1 }}>
            <Text style={styles.tripTitle}>Verified professional</Text>
            <Text style={styles.tripDesc}>Identity and background checked by Done.</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.appBg },
  mapArea: { height: 340, position: 'relative', overflow: 'hidden' },
  userPin: { position: 'absolute', left: '78%', top: '28%', width: 14, height: 14, borderRadius: 7, backgroundColor: colors.ink, borderWidth: 3, borderColor: colors.white },
  workerPin: { position: 'absolute', left: '32%', top: '64%', width: 34, height: 34, borderRadius: 17, backgroundColor: colors.gold, borderWidth: 3, borderColor: colors.white, alignItems: 'center', justifyContent: 'center' },
  mapTopRow: { position: 'absolute', top: 44, left: 20, right: 20, flexDirection: 'row', alignItems: 'center', gap: 12 },
  mapBackBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center' },
  etaPill: { backgroundColor: colors.white, borderRadius: 20, paddingVertical: 8, paddingHorizontal: 16 },
  etaLabel: { fontSize: 12.5, fontWeight: '600', color: colors.ink },
  content: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 60 },
  personRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingBottom: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border, marginBottom: 16 },
  avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.goldSoft, alignItems: 'center', justifyContent: 'center' },
  avatarLabel: { color: colors.gold, fontWeight: '700', fontFamily: fonts.serif, fontSize: 16 },
  personName: { fontFamily: fonts.sansSemiBold, fontSize: 14.5, fontWeight: '600', color: colors.ink },
  personMeta: { fontSize: 11.5, color: colors.textFaint, marginTop: 2 },
  callBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.ink, alignItems: 'center', justifyContent: 'center' },
  msgBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  sectionLabel: { fontSize: 11, letterSpacing: 0.5, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 10 },
  locationCard: { backgroundColor: colors.white, borderWidth: 0.5, borderColor: colors.border, borderRadius: 12, padding: 14, marginBottom: 16 },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  addressText: { fontSize: 13, color: colors.ink },
  shareRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 },
  shareLabel: { fontSize: 12, color: colors.textMuted },
  toggleTrack: { width: 42, height: 24, borderRadius: 20, position: 'relative' },
  toggleThumb: { position: 'absolute', width: 18, height: 18, borderRadius: 9, backgroundColor: colors.white, top: 3 },
  sharingNote: { fontSize: 11, color: colors.gold, marginTop: 8 },
  tripRow: { flexDirection: 'row', gap: 12, alignItems: 'flex-start', paddingVertical: 12 },
  tripBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  tripTitle: { fontFamily: fonts.sansSemiBold, fontSize: 13, fontWeight: '600', color: colors.ink },
  tripDesc: { fontSize: 11.5, marginTop: 2, color: colors.textMuted },
});
