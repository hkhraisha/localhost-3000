import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { bookingSeeds, BookingSeed, chatSeed } from '../data/content';

const STORAGE_KEY = 'done-app:v1';

export interface Provider {
  id: number;
  name: string;
  category: string;
  phone: string;
  rate: string;
  bio: string;
}

export interface ChatMessage {
  from: 'ai' | 'user';
  text: string;
}

export interface Suggestion {
  text: string;
  submittedAt: string;
}

interface PersistedState {
  providers: Provider[];
  messages: ChatMessage[];
  feedbackRating: number;
  feedbackSubmitted: boolean;
  suggestions: Suggestion[];
  bookingsUpcoming: BookingSeed[];
  bookingsPast: BookingSeed[];
}

const defaultState: PersistedState = {
  providers: [],
  messages: chatSeed,
  feedbackRating: 4,
  feedbackSubmitted: false,
  suggestions: [],
  bookingsUpcoming: bookingSeeds.upcoming,
  bookingsPast: bookingSeeds.past,
};

interface AppStateContextValue extends PersistedState {
  hydrated: boolean;
  chatInput: string;
  setChatInput: (v: string) => void;
  sendChat: () => void;
  setFeedbackRating: (n: number) => void;
  submitFeedback: (text: string) => void;
  addProvider: (p: Omit<Provider, 'id'>) => string | null;
  removeProvider: (id: number) => void;
  tracking: BookingSeed | null;
  startTracking: (b: BookingSeed) => void;
  stopTracking: () => void;
  locationSharing: boolean;
  toggleLocationSharing: () => void;
}

const AppStateContext = createContext<AppStateContextValue | null>(null);

export function AppStateProvider({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [state, setState] = useState<PersistedState>(defaultState);
  const [chatInput, setChatInput] = useState('');
  const [tracking, setTracking] = useState<BookingSeed | null>(null);
  const [locationSharing, setLocationSharing] = useState(true);
  const loadedOnce = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          setState((s) => ({ ...s, ...parsed }));
        }
      } catch {
        // ignore corrupt storage, fall back to defaults
      } finally {
        loadedOnce.current = true;
        setHydrated(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (!loadedOnce.current) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => {});
  }, [state]);

  const sendChat = () => {
    const text = chatInput.trim();
    if (!text) return;
    setState((s) => ({ ...s, messages: [...s.messages, { from: 'user', text }] }));
    setChatInput('');
    setTimeout(() => {
      setState((s) => ({
        ...s,
        messages: [...s.messages, { from: 'ai', text: "Got it — I'm finding the best vetted professional for that now." }],
      }));
    }, 700);
  };

  const setFeedbackRating = (n: number) => setState((s) => ({ ...s, feedbackRating: n }));

  const submitFeedback = (text: string) => {
    setState((s) => ({
      ...s,
      feedbackSubmitted: true,
      suggestions: text.trim() ? [{ text: text.trim(), submittedAt: 'just now' }, ...s.suggestions] : s.suggestions,
    }));
  };

  const addProvider: AppStateContextValue['addProvider'] = (p) => {
    if (!p.name.trim() || !p.phone.trim() || !p.rate.trim()) {
      return 'Name, phone, and rate are required.';
    }
    setState((s) => ({ ...s, providers: [...s.providers, { ...p, id: Date.now() }] }));
    return null;
  };

  const removeProvider = (id: number) => setState((s) => ({ ...s, providers: s.providers.filter((p) => p.id !== id) }));

  const startTracking = (b: BookingSeed) => setTracking(b);
  const stopTracking = () => setTracking(null);
  const toggleLocationSharing = () => setLocationSharing((v) => !v);

  const value = useMemo<AppStateContextValue>(
    () => ({
      ...state,
      hydrated,
      chatInput,
      setChatInput,
      sendChat,
      setFeedbackRating,
      submitFeedback,
      addProvider,
      removeProvider,
      tracking,
      startTracking,
      stopTracking,
      locationSharing,
      toggleLocationSharing,
    }),
    [state, hydrated, chatInput, tracking, locationSharing]
  );

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}
