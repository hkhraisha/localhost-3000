export const colors = {
  pageBg: '#EDEAE2',
  appBg: '#F9F9F7',
  white: '#fff',
  ink: '#171A1E',
  ink2: '#0B0C0E',
  gold: '#BD9D5F',
  goldSoft: '#F3ECDD',
  textMuted: '#4D5465',
  textFaint: '#8A8477',
  border: '#E5E3DC',
  error: '#B85566',
  vipCardBg: '#171A1E',
  vipSubtext: '#B7BAC0',
};

export const categoryPalette = {
  blue: { bg: '#DFEAF6', fg: '#3873B4' },
  teal: { bg: '#DDF1EE', fg: '#2E8F82' },
  gold: { bg: '#F3ECDD', fg: '#BD9D5F' },
  gray: { bg: '#E7E9EE', fg: '#4D5465' },
  red: { bg: '#F6E1E3', fg: '#B85566' },
  orange: { bg: '#FBEBD2', fg: '#C6821F' },
  purple: { bg: '#E9E1F5', fg: '#7A56B0' },
  green: { bg: '#DFF0E4', fg: '#3C8A5B' },
};

// Fallback used when a category doesn't define its own bg/fg (VIP/bespoke categories)
export const defaultCategoryColor = categoryPalette.gray;
