# Done — home services booking app

A working full-stack, two-sided marketplace: customers browse a full
44-category/300+-service catalog, book and pay for a service, and share their
live location; providers sign up with the services they offer, pick up jobs,
and move them through confirmed → en route → done. Real-time updates push
over Server-Sent Events. Storage is SQLite (via Node's own built-in
`node:sqlite` — no npm dependency). No external services required to run it.

## Requirements

**Node.js 22.5+** — this app uses `node:sqlite`, which landed as an
experimental built-in around Node 22.5. (You'll see an `ExperimentalWarning`
on startup; that's expected, not an error.)

Check your version with `node -v`. If it's older than 22.5, the app exits
immediately with a clear message telling you to upgrade, rather than a
confusing module-not-found crash. Fastest fix: install/switch via
[nvm](https://github.com/nvm-sh/nvm) — `nvm install 22 && nvm use 22` — or
grab the current version from [nodejs.org](https://nodejs.org).

## Run it locally

```bash
node server.js
```

- Customer app: **http://localhost:3000**
- Provider portal: **http://localhost:3000/provider**
- Admin dashboard (optional, see below): **http://localhost:3000/admin**

Data lives in `data/done.sqlite`, created automatically on first run.
Automatic backups: a rolling WAL, plus a full point-in-time snapshot
(`VACUUM INTO`) every 30 minutes into `data/backups/` (last ~24h kept).

**Upgrading from an older version of this app** (the one that stored
everything in `data/db.json`)? Run the one-time migration first:

```bash
npm run migrate    # or: node migrate-json-to-sqlite.js
```

It imports every user, booking, payment method, charge, and feedback entry
into the new SQLite database, preserves provider assignments and login
sessions, and renames `data/db.json` to `data/db.json.migrated` so it can't
be re-imported by accident. Safe to run even if there's nothing to migrate —
it just no-ops.

### Password reset emails (optional but recommended before real users sign up)

Off by default — `forgot-password` requests are accepted either way (so the
API never reveals which emails are registered), but nothing is actually
*sent* unless SMTP is configured:

```bash
SMTP_USER=you@gmail.com SMTP_PASS=xxxxxxxxxxxxxxxx node server.js
```

- `SMTP_HOST` (default `smtp.gmail.com`), `SMTP_PORT` (default `465`), `SMTP_FROM` (defaults to `SMTP_USER`).
- **`SMTP_PASS` must be a Gmail "App Password", never your real account password.** Generate one at
  [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords) (requires 2FA enabled on the
  Google account first). An App Password is revocable independently of your real login and is exactly what
  it's for — sending mail from an app without handing over your actual credentials.
- If SMTP isn't configured, reset links are printed to the server console instead (fine for local dev, not for
  a real deployment with real users).
- The SMTP client (`lib/smtp.js`) is hand-rolled against Node's built-in `tls` module (implicit TLS / port 465,
  `AUTH LOGIN`) rather than a library like `nodemailer`, to keep the zero-npm-dependency approach. It's been
  verified against a protocol-accurate local mock server (both the success and auth-failure paths), but **not
  against a real mailbox** — this sandboxed environment blocks outbound SMTP entirely, so a real end-to-end
  send needs to be verified from wherever you actually deploy this.

### Real AI concierge (optional)

Off by default — the concierge chat uses simple keyword matching until you
set an API key:

```bash
ANTHROPIC_API_KEY=sk-ant-... node server.js
```

- Calls the real Claude API (`lib/anthropic.js`, plain `https`, no SDK) with the full 44-category/316-service
  catalog in the system prompt (~1,900 tokens, prompt-cached across requests so repeat calls are cheap) and
  forces a structured response via tool-use, so the reply and suggested services are always well-formed —
  no text-parsing involved.
- `ANTHROPIC_MODEL` (default `claude-sonnet-5`) picks the model — `claude-haiku-4-5-20251001` is a good
  cheaper/faster alternative for this use case if you want it.
- **Fails safe**: if the API call errors for any reason (bad key, rate limit, network issue), that single
  request falls back to keyword matching automatically and logs why — a concierge problem never breaks the
  chat outright. Verified by pointing it at the real API with a deliberately invalid key.
- **One current limitation**: each message is answered independently — the concierge doesn't see earlier
  turns in the conversation. This matches the existing chat's request/response shape exactly; adding real
  multi-turn memory would mean the frontend also tracking and sending conversation history, which is a
  reasonable next step if you want it.

### Admin dashboard (optional)

Off by default. To enable it, start the server with an admin token:

```bash
ADMIN_TOKEN=some-long-random-string node server.js
```

Then open `/admin` and enter that same token. Without `ADMIN_TOKEN` set, the
admin API routes don't exist as far as any client can tell (404, not
401/403) — nothing to accidentally expose.

## What's real vs. what's still a placeholder

**Real and working:**
- Customer **and** provider accounts (shared signup/login, `role: 'customer'|'provider'`), passwords hashed with scrypt, sessions expire after 30 days (and are force-invalidated everywhere on password reset), rate limiting on login/signup/forgot-password, minimum password length, email format validation.
- **Password reset via real email** (see setup above) — token-based, 1-hour expiry, single-use, doesn't leak which emails are registered.
- The full catalog: 44 categories, 316 individual services, search across both, category drill-down.
- Booking a service (date, time, address, notes), with priced categories requiring payment upfront; "On request" categories are booked without a charge.
- **A real job lifecycle**: bookings sit in an "available jobs" pool for matching providers until one accepts (atomically — two providers racing for the same job can't both win it, enforced at the database level), then advances it themselves (`confirmed → en_route → done`), or releases it back to the pool. Customers see who's assigned once accepted.
- **A self-contained mock payment processor** — no external service, no API keys, no real money moves. Real Luhn validation, card brand detection, and well-known Stripe test-card numbers (shown in the add-card form) drive success/decline behavior, so swapping in real Stripe test mode later means the same test numbers behave the same way. Billing history is real and queryable.
- **Real GPS location sharing**: the customer's browser streams location to the server; the assigned provider sees it live, and a token-gated public link (`/track/:token`) works too for sharing outside the app.
- **Real-time push** via Server-Sent Events (`/api/events`, no external deps) — a customer's bookings and a provider's job lists update themselves the instant something changes, instead of waiting for the next poll. Polling stays underneath as a fallback.
- Feedback submission, visible in the admin dashboard.
- **SQLite storage** with real transactions, indexes, and foreign-key constraints (see "Storage" below) plus automatic backups and corrupt-database protection (WAL mode).
- Security response headers (nosniff/frame-deny/referrer-policy).
- **A real AI concierge** (see setup above) — code is fully wired to the real Claude API via structured tool-use output, with automatic fallback to keyword matching if the API call ever fails. Keyword matching is what runs until you add `ANTHROPIC_API_KEY`.

**Genuinely still open — needs your input, not just more building:**
- **Real payment processing.** The processor is a self-contained simulation by design (per your earlier choice) — real money moving requires your own Stripe (or other processor) account and API keys.

**Worth knowing about what was just built:**
- **Password reset email delivery is unverified against a real mailbox.** The SMTP client works correctly against a protocol-accurate test server (see `lib/smtp.js`'s comment), but this sandboxed build environment has no outbound SMTP access at all, so I couldn't do a real send-and-receive test with your actual Gmail account. Test it for real once deployed — send yourself a reset email and confirm it lands (check spam too; a fresh sending identity often does on the first few sends).
- **The AI concierge's Claude API integration is verified for connectivity and graceful fallback** (confirmed this sandbox can reach `api.anthropic.com`, and confirmed an invalid key correctly falls back to keyword matching rather than erroring), **but not for real conversation quality** — no valid API key was available to test an actual successful response. Try a few real messages once you add your key.
- **You shared your real Gmail password in this conversation.** I did not use it anywhere — the app reads `SMTP_USER`/`SMTP_PASS` from environment variables you set yourself, and I never wrote your actual password into any file. But please rotate that password (myaccount.google.com/security) regardless, since it was exposed in plaintext here. Use a Gmail **App Password** for `SMTP_PASS` instead, per the setup instructions above.

## Storage

SQLite via `node:sqlite` (`data/db.js`) — proper foreign keys, indexes, and
transactions instead of a hand-rolled JSON file. This directly addresses
"expecting traffic soon": writes are no longer full-file rewrites, lookups
are indexed instead of linear array scans, and the accept-a-job race
condition is closed at the database level (an atomic conditional `UPDATE`,
not a check-then-write in application code).

Automatic backups: `VACUUM INTO` snapshots every 30 minutes (`data/backups/`,
~24h of history kept) — safe to run against a live database, produces a
consistent point-in-time copy.

## Deploying it

- **Render / Railway / Fly.io**: point them at this repo, start command `node server.js`. Set `ADMIN_TOKEN`, `SMTP_USER`/`SMTP_PASS`, etc. as environment variables in their dashboard.
- **A VPS**: `node server.js` behind Caddy for TLS — see `Caddyfile.example` (rename to `Caddyfile`, swap in your domain, `caddy run`). Run the app with `pm2` (or similar) for restarts.
- `data/` (both `done.sqlite` and `backups/`) needs to live on **persistent disk** — on platforms with ephemeral filesystems (serverless targets especially), attach a persistent volume.
- Put a reverse proxy in front for HTTPS — required for location sharing and clipboard-copy to work off `localhost`. SSE (real-time updates) streams through a standard reverse proxy without extra configuration.
- Outbound port 465 (SMTP) needs to be allowed by your host for password-reset emails to actually send — most VPS providers allow this, though it's worth confirming (some specifically block outbound mail ports to fight spam).

## Project structure

```
server.js               — HTTP server: auth, bookings, provider jobs, payments,
                           location sharing, admin API, password reset, SSE
data/db.js               — SQLite data access layer (schema, queries, backups)
data/services.js         — the full service catalog (44 categories, 316 services)
data/done.sqlite         — created at runtime; all persistent app data
data/backups/            — timestamped snapshots, every 30 min, ~24h retained
migrate-json-to-sqlite.js — one-time importer from the older JSON-file storage
lib/smtp.js              — minimal hand-rolled SMTP client (implicit TLS, AUTH LOGIN)
lib/anthropic.js         — minimal Claude API client (tool-use, prompt caching)
lib/check-node-version.js — friendly error (not a crash) if Node is too old
public/index.html        — customer app shell
public/app.js            — customer app logic (auth, browsing, booking, payments,
                            location sharing, chat, profile, password reset)
public/styles.css        — customer app visual design
public/provider.html     — provider portal shell
public/provider.js       — provider portal logic (signup w/ specialties, job
                           pool, accept/release/status, profile, password reset)
public/provider.css      — provider portal visual design
public/reset-password.html — the page a password-reset email link points to
public/track.html        — public, token-gated live-location page (no login)
public/admin.html        — token-gated read-only operational dashboard
Caddyfile.example        — ready-to-use HTTPS reverse-proxy config
```
