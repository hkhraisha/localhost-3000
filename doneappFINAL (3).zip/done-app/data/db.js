// SQLite data access layer — built on Node's own `node:sqlite` (stable-ish
// experimental as of Node 22.5+), so this stays true to the project's
// zero-npm-dependency approach while getting real transactions, indexes, and
// constraint enforcement instead of a hand-rolled JSON file.
//
// Every exported function here is synchronous (node:sqlite's DatabaseSync is
// synchronous), matching the style the rest of this app already uses.

const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname);
const DB_PATH = path.join(DATA_DIR, 'done.sqlite');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL CHECK(role IN ('customer','provider')),
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  bio TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

CREATE TABLE IF NOT EXISTS provider_categories (
  provider_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_key TEXT NOT NULL,
  PRIMARY KEY (provider_id, category_key)
);
CREATE INDEX IF NOT EXISTS idx_provider_categories_key ON provider_categories(category_key);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER
);

CREATE TABLE IF NOT EXISTS password_resets (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  provider_id INTEGER REFERENCES users(id),
  service_key TEXT NOT NULL,
  sub_service TEXT,
  service_title TEXT NOT NULL,
  service_icon TEXT NOT NULL,
  price REAL NOT NULL,
  price_label TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  address TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  tracking_token TEXT NOT NULL UNIQUE,
  location_sharing INTEGER NOT NULL DEFAULT 0,
  location_lat REAL,
  location_lng REAL,
  location_updated_at TEXT,
  payment_status TEXT NOT NULL,
  charge_id INTEGER
);
CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_provider ON bookings(provider_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status_service ON bookings(status, service_key);

CREATE TABLE IF NOT EXISTS payment_methods (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  brand TEXT NOT NULL,
  last4 TEXT NOT NULL,
  exp_month INTEGER NOT NULL,
  exp_year INTEGER NOT NULL,
  name TEXT NOT NULL,
  decline_reason TEXT,
  is_default INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_payment_methods_user ON payment_methods(user_id);

CREATE TABLE IF NOT EXISTS charges (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  booking_id INTEGER REFERENCES bookings(id),
  payment_method_id INTEGER,
  payment_method_label TEXT NOT NULL,
  amount REAL NOT NULL,
  currency TEXT NOT NULL,
  status TEXT NOT NULL,
  reason TEXT,
  service_title TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_charges_user ON charges(user_id);

CREATE TABLE IF NOT EXISTS feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  rating INTEGER,
  message TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
`);

// Reentrant: several helpers below (e.g. Users.create calling
// Categories.setForProvider) call this from inside another withTransaction.
// SQLite doesn't allow nested BEGIN, so only the outermost call actually
// opens/closes a transaction — inner calls just run inline, and any error
// still propagates up to trigger the outer ROLLBACK.
let txDepth = 0;
function withTransaction(fn) {
  if (txDepth > 0) {
    txDepth++;
    try {
      return fn();
    } finally {
      txDepth--;
    }
  }
  txDepth = 1;
  db.exec('BEGIN');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    txDepth = 0;
  }
}

function snapshotBackup() {
  try {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const dest = path.join(BACKUP_DIR, `done-${stamp}.sqlite`);
    db.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`);
    const files = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.sqlite')).sort();
    const MAX_SNAPSHOTS = 48; // ~24h of history at the 30-min interval this is called on
    while (files.length > MAX_SNAPSHOTS) fs.unlinkSync(path.join(BACKUP_DIR, files.shift()));
  } catch (e) {
    console.error('Snapshot backup failed:', e.message);
  }
}

// ---------- row <-> app-shape helpers ----------

function userRowToObject(row) {
  if (!row) return null;
  return {
    id: row.id, role: row.role, name: row.name, email: row.email, phone: row.phone,
    passwordHash: row.password_hash, bio: row.bio, createdAt: row.created_at,
    categories: row.role === 'provider' ? Categories.getForProvider(row.id) : [],
  };
}

function bookingRowToObject(row) {
  if (!row) return null;
  return {
    id: row.id, userId: row.user_id, providerId: row.provider_id,
    serviceKey: row.service_key, subService: row.sub_service,
    serviceTitle: row.service_title, serviceIcon: row.service_icon,
    price: row.price, priceLabel: row.price_label,
    date: row.date, time: row.time, address: row.address, notes: row.notes,
    status: row.status, createdAt: row.created_at, trackingToken: row.tracking_token,
    locationSharing: !!row.location_sharing,
    location: row.location_sharing && row.location_lat != null
      ? { lat: row.location_lat, lng: row.location_lng, updatedAt: row.location_updated_at }
      : null,
    paymentStatus: row.payment_status, chargeId: row.charge_id,
  };
}

function paymentMethodRowToObject(row) {
  if (!row) return null;
  return {
    id: row.id, userId: row.user_id, brand: row.brand, last4: row.last4,
    expMonth: row.exp_month, expYear: row.exp_year, name: row.name,
    declineReason: row.decline_reason, isDefault: !!row.is_default, createdAt: row.created_at,
  };
}

function chargeRowToObject(row) {
  if (!row) return null;
  return {
    id: row.id, userId: row.user_id, bookingId: row.booking_id,
    paymentMethodId: row.payment_method_id, paymentMethodLabel: row.payment_method_label,
    amount: row.amount, currency: row.currency, status: row.status, reason: row.reason,
    serviceTitle: row.service_title, createdAt: row.created_at,
  };
}

function feedbackRowToObject(row) {
  if (!row) return null;
  return { id: row.id, userId: row.user_id, rating: row.rating, message: row.message, createdAt: row.created_at };
}

// ---------- Users ----------

const Users = {
  findByEmail(email) {
    const row = db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').get(String(email || ''));
    return userRowToObject(row);
  },
  findById(id) {
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    return userRowToObject(row);
  },
  create({ role, name, email, phone, passwordHash, bio, categories }) {
    return withTransaction(() => {
      const info = db.prepare(
        'INSERT INTO users (role, name, email, phone, password_hash, bio, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).run(role, name, email, phone || '', passwordHash, bio || '', new Date().toISOString());
      const id = Number(info.lastInsertRowid);
      if (role === 'provider' && Array.isArray(categories)) {
        Categories.setForProvider(id, categories);
      }
      return Users.findById(id);
    });
  },
  update(id, { name, phone, bio }) {
    const current = Users.findById(id);
    if (!current) return null;
    db.prepare('UPDATE users SET name = ?, phone = ?, bio = ? WHERE id = ?').run(
      name !== undefined ? name : current.name,
      phone !== undefined ? phone : current.phone,
      bio !== undefined ? bio : current.bio,
      id
    );
    return Users.findById(id);
  },
  countByRole(role) {
    return db.prepare('SELECT COUNT(*) AS n FROM users WHERE role = ?').get(role).n;
  },
  all() {
    return db.prepare('SELECT * FROM users ORDER BY id').all().map(userRowToObject);
  },
  setPasswordHash(id, passwordHash) {
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(passwordHash, id);
  },
};

const Categories = {
  getForProvider(providerId) {
    return db.prepare('SELECT category_key FROM provider_categories WHERE provider_id = ?').all(providerId).map(r => r.category_key);
  },
  setForProvider(providerId, categories) {
    withTransaction(() => {
      db.prepare('DELETE FROM provider_categories WHERE provider_id = ?').run(providerId);
      const insert = db.prepare('INSERT OR IGNORE INTO provider_categories (provider_id, category_key) VALUES (?, ?)');
      for (const key of categories) insert.run(providerId, key);
    });
  },
};

// ---------- Sessions ----------

const Sessions = {
  create(token, userId, expiresAt) {
    db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)').run(token, userId, expiresAt);
  },
  get(token) {
    const row = db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
    if (!row) return null;
    if (row.expires_at && row.expires_at < Date.now()) {
      Sessions.delete(token);
      return null;
    }
    return { userId: row.user_id, expiresAt: row.expires_at };
  },
  delete(token) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
  },
  // Called on password reset — if the account was compromised, this makes
  // sure resetting the password also kicks out anyone using a stolen session.
  deleteAllForUser(userId) {
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
  },
  deleteExpired() {
    db.prepare('DELETE FROM sessions WHERE expires_at IS NOT NULL AND expires_at < ?').run(Date.now());
  },
};

// ---------- Password resets ----------

const PasswordResets = {
  create(token, userId, expiresAt) {
    db.prepare('INSERT INTO password_resets (token, user_id, expires_at, used) VALUES (?, ?, ?, 0)').run(token, userId, expiresAt);
  },
  get(token) {
    const row = db.prepare('SELECT * FROM password_resets WHERE token = ?').get(token);
    if (!row) return null;
    return { userId: row.user_id, expiresAt: row.expires_at, used: !!row.used };
  },
  markUsed(token) {
    db.prepare('UPDATE password_resets SET used = 1 WHERE token = ?').run(token);
  },
  deleteExpired() {
    db.prepare('DELETE FROM password_resets WHERE expires_at < ?').run(Date.now());
  },
};

// ---------- Bookings ----------

const Bookings = {
  create(b) {
    const info = db.prepare(`
      INSERT INTO bookings (user_id, provider_id, service_key, sub_service, service_title, service_icon,
        price, price_label, date, time, address, notes, status, created_at, tracking_token,
        location_sharing, payment_status, charge_id)
      VALUES (?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
    `).run(
      b.userId, b.serviceKey, b.subService, b.serviceTitle, b.serviceIcon,
      b.price, b.priceLabel, b.date, b.time, b.address, b.notes || '', b.status,
      b.createdAt, b.trackingToken, b.paymentStatus, b.chargeId
    );
    return Bookings.findById(Number(info.lastInsertRowid));
  },
  findById(id) {
    return bookingRowToObject(db.prepare('SELECT * FROM bookings WHERE id = ?').get(id));
  },
  findByUser(userId) {
    return db.prepare('SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC').all(userId).map(bookingRowToObject);
  },
  findByTrackingToken(token) {
    return bookingRowToObject(db.prepare('SELECT * FROM bookings WHERE tracking_token = ?').get(token));
  },
  findAvailableForProvider(providerId) {
    return db.prepare(`
      SELECT b.* FROM bookings b
      JOIN provider_categories pc ON pc.category_key = b.service_key
      WHERE pc.provider_id = ? AND b.status = 'pending' AND b.provider_id IS NULL
      ORDER BY b.created_at ASC
    `).all(providerId).map(bookingRowToObject);
  },
  findByProvider(providerId) {
    return db.prepare('SELECT * FROM bookings WHERE provider_id = ? ORDER BY created_at DESC').all(providerId).map(bookingRowToObject);
  },
  setChargeId(id, chargeId) {
    db.prepare('UPDATE bookings SET charge_id = ? WHERE id = ?').run(chargeId, id);
  },
  cancel(id) {
    db.prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?").run(id);
    return Bookings.findById(id);
  },
  // Atomic accept: only succeeds if still pending & unassigned, preventing
  // the same race two concurrent "accept" requests could otherwise hit.
  acceptIfAvailable(id, providerId) {
    return withTransaction(() => {
      const info = db.prepare("UPDATE bookings SET provider_id = ?, status = 'confirmed' WHERE id = ? AND status = 'pending' AND provider_id IS NULL")
        .run(providerId, id);
      return info.changes > 0 ? Bookings.findById(id) : null;
    });
  },
  release(id, providerId) {
    const info = db.prepare("UPDATE bookings SET provider_id = NULL, status = 'pending' WHERE id = ? AND provider_id = ?").run(id, providerId);
    return info.changes > 0;
  },
  setStatus(id, providerId, status) {
    db.prepare('UPDATE bookings SET status = ? WHERE id = ? AND provider_id = ?').run(status, id, providerId);
    return Bookings.findById(id);
  },
  setLocationSharing(id, enabled) {
    if (enabled) {
      db.prepare('UPDATE bookings SET location_sharing = 1 WHERE id = ?').run(id);
    } else {
      db.prepare('UPDATE bookings SET location_sharing = 0, location_lat = NULL, location_lng = NULL, location_updated_at = NULL WHERE id = ?').run(id);
    }
    return Bookings.findById(id);
  },
  setLocation(id, lat, lng) {
    db.prepare('UPDATE bookings SET location_lat = ?, location_lng = ?, location_updated_at = ? WHERE id = ?')
      .run(lat, lng, new Date().toISOString(), id);
  },
  all() {
    return db.prepare('SELECT * FROM bookings ORDER BY id DESC').all().map(bookingRowToObject);
  },
};

// ---------- Payment methods ----------

const PaymentMethods = {
  findByUser(userId) {
    return db.prepare('SELECT * FROM payment_methods WHERE user_id = ? ORDER BY id').all(userId).map(paymentMethodRowToObject);
  },
  findById(id, userId) {
    return paymentMethodRowToObject(db.prepare('SELECT * FROM payment_methods WHERE id = ? AND user_id = ?').get(id, userId));
  },
  findDefault(userId) {
    return paymentMethodRowToObject(db.prepare('SELECT * FROM payment_methods WHERE user_id = ? AND is_default = 1').get(userId));
  },
  create(pm) {
    return withTransaction(() => {
      const isFirst = db.prepare('SELECT COUNT(*) AS n FROM payment_methods WHERE user_id = ?').get(pm.userId).n === 0;
      const info = db.prepare(`
        INSERT INTO payment_methods (user_id, brand, last4, exp_month, exp_year, name, decline_reason, is_default, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(pm.userId, pm.brand, pm.last4, pm.expMonth, pm.expYear, pm.name, pm.declineReason, isFirst ? 1 : 0, new Date().toISOString());
      return PaymentMethods.findById(Number(info.lastInsertRowid), pm.userId);
    });
  },
  setDefault(userId, id) {
    return withTransaction(() => {
      db.prepare('UPDATE payment_methods SET is_default = 0 WHERE user_id = ?').run(userId);
      db.prepare('UPDATE payment_methods SET is_default = 1 WHERE id = ? AND user_id = ?').run(id, userId);
      return PaymentMethods.findById(id, userId);
    });
  },
  delete(id, userId) {
    return withTransaction(() => {
      const pm = PaymentMethods.findById(id, userId);
      if (!pm) return false;
      db.prepare('DELETE FROM payment_methods WHERE id = ? AND user_id = ?').run(id, userId);
      if (pm.isDefault) {
        const next = db.prepare('SELECT id FROM payment_methods WHERE user_id = ? ORDER BY id LIMIT 1').get(userId);
        if (next) db.prepare('UPDATE payment_methods SET is_default = 1 WHERE id = ?').run(next.id);
      }
      return true;
    });
  },
};

// ---------- Charges ----------

const Charges = {
  create(c) {
    const info = db.prepare(`
      INSERT INTO charges (user_id, booking_id, payment_method_id, payment_method_label, amount, currency, status, reason, service_title, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(c.userId, c.bookingId, c.paymentMethodId, c.paymentMethodLabel, c.amount, c.currency, c.status, c.reason, c.serviceTitle, new Date().toISOString());
    return Charges.findById(Number(info.lastInsertRowid));
  },
  findById(id) {
    return chargeRowToObject(db.prepare('SELECT * FROM charges WHERE id = ?').get(id));
  },
  findByUser(userId) {
    return db.prepare('SELECT * FROM charges WHERE user_id = ? ORDER BY created_at DESC').all(userId).map(chargeRowToObject);
  },
  all() {
    return db.prepare('SELECT * FROM charges ORDER BY id DESC').all().map(chargeRowToObject);
  },
  totalSucceeded() {
    return db.prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM charges WHERE status = 'succeeded'").get().total;
  },
  count() {
    return db.prepare('SELECT COUNT(*) AS n FROM charges').get().n;
  },
};

// ---------- Feedback ----------

const Feedback = {
  create(f) {
    const info = db.prepare('INSERT INTO feedback (user_id, rating, message, created_at) VALUES (?, ?, ?, ?)')
      .run(f.userId, f.rating, f.message || '', new Date().toISOString());
    return feedbackRowToObject(db.prepare('SELECT * FROM feedback WHERE id = ?').get(Number(info.lastInsertRowid)));
  },
  all() {
    return db.prepare('SELECT * FROM feedback ORDER BY id DESC').all().map(feedbackRowToObject);
  },
  count() {
    return db.prepare('SELECT COUNT(*) AS n FROM feedback').get().n;
  },
};

module.exports = { db, Users, Categories, Sessions, PasswordResets, Bookings, PaymentMethods, Charges, Feedback, snapshotBackup, BACKUP_DIR, DB_PATH };
