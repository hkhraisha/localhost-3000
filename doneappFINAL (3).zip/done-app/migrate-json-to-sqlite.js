// One-time migration: imports an existing data/db.json (from the JSON-file
// storage this app used before) into the new data/done.sqlite database.
// Safe to run multiple times — it's a no-op if db.json doesn't exist, and it
// renames db.json to db.json.migrated on success so it won't be re-imported.
//
// Usage: node migrate-json-to-sqlite.js

require('./lib/check-node-version.js').checkNodeVersion();

const fs = require('fs');
const path = require('path');

const JSON_PATH = path.join(__dirname, 'data', 'db.json');

if (!fs.existsSync(JSON_PATH)) {
  console.log('No data/db.json found — nothing to migrate. (This is expected on a fresh install.)');
  process.exit(0);
}

const { Users, Categories, Sessions, Bookings, PaymentMethods, Charges, Feedback } = require('./data/db.js');

const old = JSON.parse(fs.readFileSync(JSON_PATH, 'utf8'));

console.log(`Migrating ${old.users?.length || 0} users, ${old.bookings?.length || 0} bookings, ${old.paymentMethods?.length || 0} payment methods, ${old.charges?.length || 0} charges, ${old.feedback?.length || 0} feedback entries...`);

const idMap = new Map(); // old user id -> new user id (should be identical, but don't assume)

for (const u of old.users || []) {
  const created = Users.create({
    role: u.role || 'customer',
    name: u.name,
    email: u.email,
    phone: u.phone || '',
    passwordHash: u.passwordHash,
    bio: u.bio || '',
    categories: u.categories || [],
  });
  idMap.set(u.id, created.id);
}

for (const [token, session] of Object.entries(old.sessions || {})) {
  const oldUserId = typeof session === 'number' ? session : session.userId;
  const newUserId = idMap.get(oldUserId);
  if (!newUserId) continue;
  const expiresAt = typeof session === 'number' ? null : session.expiresAt;
  try { Sessions.create(token, newUserId, expiresAt); } catch (e) { /* duplicate token, skip */ }
}

const bookingIdMap = new Map();
for (const b of old.bookings || []) {
  const newUserId = idMap.get(b.userId);
  if (!newUserId) continue;
  const created = Bookings.create({
    userId: newUserId,
    serviceKey: b.serviceKey,
    subService: b.subService || null,
    serviceTitle: b.serviceTitle,
    serviceIcon: b.serviceIcon,
    price: b.price,
    priceLabel: b.priceLabel,
    date: b.date,
    time: b.time,
    address: b.address,
    notes: b.notes || '',
    status: b.status,
    createdAt: b.createdAt,
    trackingToken: b.trackingToken,
    paymentStatus: b.paymentStatus || 'not_required',
    chargeId: null, // fixed up after charges are migrated below
  });
  bookingIdMap.set(b.id, created.id);
  if (b.providerId && idMap.has(b.providerId)) {
    // restore assignment/status directly (bypasses the normal accept flow,
    // which is correct here — this is a data migration, not a live action)
    const { db } = require('./data/db.js');
    db.prepare('UPDATE bookings SET provider_id = ?, status = ? WHERE id = ?').run(idMap.get(b.providerId), b.status, created.id);
  }
  if (b.locationSharing) {
    Bookings.setLocationSharing(created.id, true);
    if (b.location) Bookings.setLocation(created.id, b.location.lat, b.location.lng);
  }
}

for (const pm of old.paymentMethods || []) {
  const newUserId = idMap.get(pm.userId);
  if (!newUserId) continue;
  PaymentMethods.create({
    userId: newUserId, brand: pm.brand, last4: pm.last4, expMonth: pm.expMonth, expYear: pm.expYear,
    name: pm.name, declineReason: pm.declineReason || null,
  });
  // create() always makes the first one default; re-apply the original default flag explicitly
}
// Re-apply original default flags now that all payment methods for each user exist
for (const pm of old.paymentMethods || []) {
  if (!pm.isDefault) continue;
  const newUserId = idMap.get(pm.userId);
  if (!newUserId) continue;
  const mine = PaymentMethods.findByUser(newUserId);
  const match = mine.find(m => m.last4 === pm.last4 && m.brand === pm.brand);
  if (match) PaymentMethods.setDefault(newUserId, match.id);
}

for (const c of old.charges || []) {
  const newUserId = idMap.get(c.userId);
  if (!newUserId) continue;
  const newBookingId = c.bookingId ? bookingIdMap.get(c.bookingId) : null;
  const created = Charges.create({
    userId: newUserId, bookingId: newBookingId || null, paymentMethodId: null,
    paymentMethodLabel: c.paymentMethodLabel, amount: c.amount, currency: c.currency,
    status: c.status, reason: c.reason || null, serviceTitle: c.serviceTitle,
  });
  if (newBookingId) Bookings.setChargeId(newBookingId, created.id);
}

for (const f of old.feedback || []) {
  const newUserId = f.userId ? idMap.get(f.userId) : null;
  Feedback.create({ userId: newUserId || null, rating: f.rating, message: f.message });
}

fs.renameSync(JSON_PATH, JSON_PATH + '.migrated');
console.log('Migration complete. data/db.json renamed to data/db.json.migrated (kept for reference, no longer read by the app).');
console.log('Data now lives in data/done.sqlite.');
