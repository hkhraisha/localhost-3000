// ---------- state ----------
let TOKEN = localStorage.getItem('done_token') || null;
let CURRENT_USER = null;
let SERVICES = [];
let SERVICES_BY_KEY = {};
let CATEGORIES = [];
let authMode = 'login';
let activeDetailKey = null;
let bookingsCache = [];

const ICON_COLORS = ['c-amber', 'c-green', 'c-blue', 'c-rose', 'c-purple', 'c-teal', 'c-gold', 'c-slate'];
function colorFor(key) {
  let h = 0;
  for (const c of key) h += c.charCodeAt(0);
  return ICON_COLORS[h % ICON_COLORS.length];
}

// ---------- API helper ----------
async function api(path, method = 'GET', body) {
  const headers = { 'Content-Type': 'application/json' };
  if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;
  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

// ---------- init ----------
async function init() {
  const clock = document.getElementById('clock');
  const now = new Date();
  clock.textContent = now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  try {
    const catRes = await api('/api/categories');
    CATEGORIES = catRes.categories;
    const svcRes = await api('/api/services');
    SERVICES = svcRes.services;
    SERVICES_BY_KEY = Object.fromEntries(SERVICES.map(s => [s.key, s]));
  } catch (e) {
    showToast('Could not reach the server. Is it running?', true);
    return;
  }

  buildFilterTabs();
  buildHomeSections();
  buildPlusSections();
  buildStarRow();

  if (TOKEN) {
    try {
      const me = await api('/api/me');
      CURRENT_USER = me.user;
      showApp();
    } catch (e) {
      TOKEN = null;
      localStorage.removeItem('done_token');
      showAuth();
    }
  } else {
    showAuth();
  }
}

function showAuth() {
  document.getElementById('authscreen').style.display = 'block';
  document.getElementById('mainapp').style.display = 'none';
  document.getElementById('navbar').style.display = 'none';
}

function showApp() {
  document.getElementById('authscreen').style.display = 'none';
  document.getElementById('mainapp').style.display = 'block';
  document.getElementById('navbar').style.display = 'flex';
  const firstName = (CURRENT_USER.name || '').split(' ')[0] || 'there';
  document.getElementById('home-greet-name').textContent = firstName;
  document.getElementById('concierge-greet-name').textContent = firstName;
  document.getElementById('profile-name').textContent = CURRENT_USER.name;
  document.getElementById('profile-email').textContent = CURRENT_USER.email;
  document.getElementById('profile-avatar').textContent = (CURRENT_USER.name || '?').trim()[0].toUpperCase();
  loadPaymentMethods();
  connectEvents();
  showTab('home');
}

// ---------- real-time updates (Server-Sent Events) ----------
// Supplements, doesn't replace, the polling already used to load bookings —
// this just makes the currently-open bookings tab refresh itself the moment
// something changes server-side, instead of waiting for the next tab switch.
let eventSource = null;
function connectEvents() {
  if (eventSource) eventSource.close();
  eventSource = new EventSource(`/api/events?token=${encodeURIComponent(TOKEN)}`);
  const onBookingChange = () => { if (document.getElementById('bookings').classList.contains('active')) renderBookings(); };
  eventSource.addEventListener('booking-updated', onBookingChange);
  eventSource.addEventListener('location-updated', onBookingChange);
  // EventSource auto-reconnects on drop; nothing else to do on error here.
}
function disconnectEvents() {
  if (eventSource) { eventSource.close(); eventSource = null; }
}

// ---------- auth ----------
function setAuthMode(mode) {
  authMode = mode;
  document.getElementById('tab-login').classList.toggle('active', mode === 'login');
  document.getElementById('tab-signup').classList.toggle('active', mode === 'signup');
  document.getElementById('signup-fields').style.display = mode === 'signup' ? 'block' : 'none';
  document.getElementById('auth-password-field').style.display = mode === 'forgot' ? 'none' : 'block';
  document.getElementById('forgot-hint').style.display = mode === 'login' ? 'block' : 'none';
  document.getElementById('auth-success').style.display = 'none';
  document.getElementById('auth-submit').textContent = mode === 'signup' ? 'Create account' : mode === 'forgot' ? 'Send reset link' : 'Log in';
  document.getElementById('auth-hint').innerHTML = mode === 'signup'
    ? 'Already have an account? <a onclick="setAuthMode(\'login\')">Log in</a>'
    : mode === 'forgot'
    ? 'Remembered it? <a onclick="setAuthMode(\'login\')">Log in</a>'
    : 'New to Done? <a onclick="setAuthMode(\'signup\')">Create an account</a>';
  document.getElementById('auth-error').textContent = '';
}

async function submitAuth() {
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const errEl = document.getElementById('auth-error');
  errEl.textContent = '';
  try {
    if (authMode === 'forgot') {
      await api('/api/auth/forgot-password', 'POST', { email });
      document.getElementById('auth-success').style.display = 'block';
      document.getElementById('auth-success').textContent = "If that email has an account, we've sent a reset link.";
      return;
    }
    let res;
    if (authMode === 'signup') {
      const name = document.getElementById('su-name').value.trim();
      const phone = document.getElementById('su-phone').value.trim();
      if (!name) { errEl.textContent = 'Please enter your name.'; return; }
      res = await api('/api/auth/signup', 'POST', { name, email, phone, password });
    } else {
      res = await api('/api/auth/login', 'POST', { email, password });
    }
    TOKEN = res.token;
    CURRENT_USER = res.user;
    localStorage.setItem('done_token', TOKEN);
    showApp();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function logout() {
  stopAllLocationWatchers();
  disconnectEvents();
  try { await api('/api/auth/logout', 'POST'); } catch (e) {}
  TOKEN = null;
  CURRENT_USER = null;
  localStorage.removeItem('done_token');
  showAuth();
}

// ---------- home ----------
const HOME_QUICK_KEYS = ['cleaning', 'plumbing', 'electric', 'automotive', 'beauty', 'chef', 'petcare'];
const HOME_QUICK_LABELS = { cleaning: 'Cleaning', plumbing: 'Plumbing', electric: 'Electrical', automotive: 'Driver', beauty: 'Beauty', chef: 'Food & Chef', petcare: 'Pets' };
const HOME_POPULAR = [
  { key: 'physician', proName: 'Dr. Rana Saleh', tag: 'Physician' },
  { key: 'massage', proName: 'Layla H.', tag: 'Massage' },
  { key: 'electric', proName: 'Omar F.', tag: 'Electrician' },
];

function iconHtml(key) {
  const s = SERVICES_BY_KEY[key];
  return s ? `<i class="ti ${s.icon}"></i>` : '<i class="ti ti-sparkles"></i>';
}

function buildHomeSections() {
  const grid = document.getElementById('home-catgrid');
  grid.innerHTML = HOME_QUICK_KEYS.map(key => {
    const s = SERVICES_BY_KEY[key];
    if (!s) return '';
    return `<div class="catitem" onclick="openDetail('${key}')"><div class="icn ${colorFor(key)}">${iconHtml(key)}</div><span>${HOME_QUICK_LABELS[key]}</span></div>`;
  }).join('') + `<div class="catitem" onclick="showTab('services')"><div class="icn c-purple"><i class="ti ti-dots"></i></div><span>View all</span></div>`;

  const pop = document.getElementById('home-popular');
  pop.innerHTML = HOME_POPULAR.map(p => {
    const s = SERVICES_BY_KEY[p.key];
    if (!s) return '';
    return `<div class="procard" onclick="openDetail('${p.key}')"><div class="avatar">${iconHtml(p.key)}</div><h3>${p.proName}</h3><div class="meta">★ ${s.rating.toFixed(1)} · ${p.tag}</div></div>`;
  }).join('');
}

function buildPlusSections() {
  const vipServices = SERVICES.filter(s => s.category === 'vip');
  const scroll = document.getElementById('plus-scroll');
  scroll.innerHTML = vipServices.slice(0, 4).map(s =>
    `<div class="procard" onclick="openDetail('${s.key}')"><div class="avatar">${iconHtml(s.key)}</div><h3>${s.title}</h3><div class="meta">${s.priceLabel}</div></div>`
  ).join('');
  const cards = document.getElementById('plus-cards');
  cards.innerHTML = vipServices.slice(4).map(s => serviceCardHtml(s)).join('');
}

function serviceCardHtml(s, matchedSub) {
  const openCall = matchedSub ? `openDetailAt('${s.key}', ${jsAttr(matchedSub)})` : `openDetail('${s.key}')`;
  return `<div class="servicecard" onclick="${openCall}">
    <div class="thumb"><i class="ti ${s.icon}"></i></div>
    <div class="info"><h3>${s.title}</h3>
      ${matchedSub ? `<div class="meta" style="margin-top:2px;"><span>Includes: ${escapeHtml(matchedSub)}</span></div>` : ''}
      <div class="meta"><span>★ ${s.rating.toFixed(1)} (${s.reviews})</span><span class="price">${s.priceLabel}</span></div>
    </div>
  </div>`;
}

// ---------- tabs / nav ----------
function showTab(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.navitem').forEach(n => n.classList.remove('active'));
  const navEl = document.getElementById('nav-' + id);
  if (navEl) navEl.classList.add('active');
  document.getElementById('detailview').classList.remove('active');
  document.getElementById('bookform').classList.remove('active');
  document.getElementById('cardform').classList.remove('active');
  if (id === 'bookings') renderBookings();
  if (id === 'profile') fillProfileFields();
  if (id === 'payment') loadPaymentMethods();
  if (id === 'billing') loadBillingHistory();
}

// ---------- payment methods ----------
let paymentMethodsCache = [];
const BRAND_ICONS = { visa: 'ti-brand-visa', mastercard: 'ti-brand-mastercard', amex: 'ti-credit-card', discover: 'ti-credit-card', card: 'ti-credit-card' };

async function loadPaymentMethods() {
  try {
    const res = await api('/api/payment-methods');
    paymentMethodsCache = res.paymentMethods;
  } catch (e) {
    paymentMethodsCache = [];
  }

  const profileSub = document.getElementById('profile-payment-sub');
  if (profileSub) {
    const def = paymentMethodsCache.find(p => p.isDefault);
    profileSub.textContent = def ? `${def.brand.charAt(0).toUpperCase() + def.brand.slice(1)} •••• ${def.last4}` : 'No card on file';
  }

  const list = document.getElementById('payment-methods-list');
  if (!list) return; // may be called (e.g. from the booking form) before the payment screen has ever rendered
  if (paymentMethodsCache.length === 0) {
    list.innerHTML = `<div class="emptystate">No payment methods yet — add one to book paid services.</div>`;
    return;
  }
  list.innerHTML = paymentMethodsCache.map(pmRowHtml).join('');
}

function pmRowHtml(pm) {
  const icon = BRAND_ICONS[pm.brand] || 'ti-credit-card';
  const expiry = `${String(pm.expMonth).padStart(2, '0')}/${String(pm.expYear).slice(-2)}`;
  return `<div class="pmrow">
    <div class="pmleft">
      <i class="ti ${icon}" style="font-size:26px;color:var(--ink);"></i>
      <div><div class="label">${pm.brand.charAt(0).toUpperCase() + pm.brand.slice(1)} •••• ${pm.last4}</div><div class="pmmeta">Expires ${expiry}</div></div>
    </div>
    <div class="pmactions">
      ${pm.isDefault ? `<span class="defaultbadge">DEFAULT</span>` : `<span class="pmaction" onclick="setDefaultPaymentMethod(${pm.id})">Set default</span>`}
      <span class="pmremove" onclick="removePaymentMethod(${pm.id})"><i class="ti ti-trash"></i></span>
    </div>
  </div>`;
}

async function setDefaultPaymentMethod(id) {
  try {
    await api(`/api/payment-methods/${id}/default`, 'PATCH');
    await loadPaymentMethods();
    showToast('Default payment method updated.');
  } catch (e) {
    showToast(e.message, true);
  }
}

async function removePaymentMethod(id) {
  try {
    await api(`/api/payment-methods/${id}`, 'DELETE');
    await loadPaymentMethods();
    showToast('Payment method removed.');
  } catch (e) {
    showToast(e.message, true);
  }
}

function openAddCardForm() {
  document.getElementById('card-name').value = '';
  document.getElementById('card-number').value = '';
  document.getElementById('card-expiry').value = '';
  document.getElementById('card-cvc').value = '';
  document.getElementById('card-error').textContent = '';
  document.getElementById('cardform').classList.add('active');
}
function closeAddCardForm() {
  document.getElementById('cardform').classList.remove('active');
}

function formatCardNumberInput(el) {
  const digits = el.value.replace(/\D/g, '').slice(0, 19);
  el.value = digits.replace(/(.{4})/g, '$1 ').trim();
}
function formatExpiryInput(el) {
  let digits = el.value.replace(/\D/g, '').slice(0, 4);
  if (digits.length >= 3) digits = digits.slice(0, 2) + '/' + digits.slice(2);
  el.value = digits;
}

async function submitAddCard() {
  const name = document.getElementById('card-name').value.trim();
  const cardNumber = document.getElementById('card-number').value;
  const expiry = document.getElementById('card-expiry').value;
  const cvc = document.getElementById('card-cvc').value.trim();
  const errEl = document.getElementById('card-error');
  const [expMonthStr, expYearStr] = expiry.split('/');
  const expMonth = Number(expMonthStr);
  const expYear = expYearStr ? Number(expYearStr) + 2000 : NaN;
  if (!name || !cardNumber.trim() || !expMonthStr || !expYearStr || !cvc) {
    errEl.textContent = 'Please fill in every field.';
    return;
  }
  errEl.textContent = '';
  try {
    await api('/api/payment-methods', 'POST', { cardNumber, expMonth, expYear, cvc, name });
    closeAddCardForm();
    await loadPaymentMethods();
    showToast('Payment method added.');
  } catch (e) {
    errEl.textContent = e.message;
  }
}

// ---------- billing history ----------
async function loadBillingHistory() {
  const list = document.getElementById('billing-list');
  list.innerHTML = '<div class="spinner"></div>';
  try {
    const res = await api('/api/billing-history');
    if (res.charges.length === 0) {
      list.innerHTML = `<div class="emptystate">No charges yet.</div>`;
      return;
    }
    list.innerHTML = res.charges.map(chargeRowHtml).join('');
  } catch (e) {
    list.innerHTML = `<div class="emptystate">${e.message}</div>`;
  }
}

function chargeRowHtml(c) {
  const date = new Date(c.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
  const statusColor = c.status === 'succeeded' ? 'var(--gold)' : 'var(--danger)';
  const statusLabel = c.status === 'succeeded' ? 'PAID' : 'DECLINED';
  return `<div class="chargerow">
    <div class="chargetop">
      <h3>${escapeHtml(c.serviceTitle)}</h3>
      <span style="font-family:'Playfair Display',serif;font-weight:700;color:var(--ink);font-size:13.5px;">${c.amount.toFixed(2)} JOD</span>
    </div>
    <div class="chargemeta">${date} · ${escapeHtml(c.paymentMethodLabel)} · <span style="color:${statusColor};font-weight:600;">${statusLabel}</span>${c.reason ? ' · ' + escapeHtml(c.reason) : ''}</div>
  </div>`;
}

// ---------- services tab ----------
function buildFilterTabs() {
  const wrap = document.getElementById('filtertabs');
  const browsable = CATEGORIES.filter(c => c.id !== 'vip');
  wrap.innerHTML = browsable.map((c, i) =>
    `<div class="filtertab ${i === 0 ? 'active' : ''}" data-cat="${c.id}" onclick="setServiceCategory('${c.id}', this)">${c.label}</div>`
  ).join('');
  currentCategory = browsable[0].id;
  renderServiceResults();
}
let currentCategory = 'home';
function setServiceCategory(id, el) {
  currentCategory = id;
  document.querySelectorAll('.filtertab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('service-search').value = '';
  renderServiceResults();
}

// A category matches a search either directly (title/description) or through
// one of its individual sub-services (e.g. "window cleaning" -> Cleaning).
function matchesQuery(s, q) {
  return s.title.toLowerCase().includes(q) || s.desc.toLowerCase().includes(q) || s.subServices.some(name => name.toLowerCase().includes(q));
}
function matchedSubService(s, q) {
  if (s.title.toLowerCase().includes(q)) return null;
  return s.subServices.find(name => name.toLowerCase().includes(q)) || null;
}

function renderServiceResults() {
  const q = document.getElementById('service-search').value.trim().toLowerCase();
  const results = document.getElementById('service-results');
  let list;
  if (q) {
    list = SERVICES.filter(s => s.category !== 'vip' && matchesQuery(s, q));
  } else {
    list = SERVICES.filter(s => s.category === currentCategory);
  }
  if (list.length === 0) {
    results.innerHTML = `<div class="emptystate">No services found.</div>`;
    return;
  }
  results.innerHTML = `<div class="section-label" style="margin-top:0;">${q ? 'Search results' : 'Featured'}</div>` +
    list.map(s => serviceCardHtml(s, q ? matchedSubService(s, q) : null)).join('');
}

// ---------- detail overlay ----------
// Two "modes", mirroring the source design: 'category' shows the category
// itself (with a drill-down list of its individual services, if any), and
// 'service' shows one specific leaf service from that list.
let detailMode = 'category';
let activeSubService = null;

function openDetail(key) {
  const s = SERVICES_BY_KEY[key];
  if (!s) return;
  activeDetailKey = key;
  detailMode = 'category';
  activeSubService = null;
  renderDetail();
  document.getElementById('detailview').classList.add('active');
}

function openServiceDetail(subServiceName) {
  detailMode = 'service';
  activeSubService = subServiceName;
  renderDetail();
}

// Used by search results that matched via a specific sub-service: opens
// straight into that service instead of the category's top-level list.
function openDetailAt(key, subServiceName) {
  openDetail(key);
  if (subServiceName) openServiceDetail(subServiceName);
}

function detailBack() {
  if (detailMode === 'service') {
    detailMode = 'category';
    activeSubService = null;
    renderDetail();
  } else {
    closeDetail();
  }
}

function renderDetail() {
  const s = SERVICES_BY_KEY[activeDetailKey];
  if (!s) return;

  const subLabelEl = document.getElementById('detail-sublabel');
  const showServicesList = detailMode === 'category' && s.subServices.length > 0;
  const showBullets = detailMode === 'service' || s.subServices.length === 0;

  if (detailMode === 'service') {
    subLabelEl.textContent = s.title;
    subLabelEl.style.display = 'inline';
    document.getElementById('detail-title').textContent = activeSubService;
    document.getElementById('detail-desc').textContent =
      `Professional ${activeSubService.toLowerCase()} through Done, delivered by a vetted ${s.title.toLowerCase()} specialist with fixed, upfront pricing.`;
  } else {
    subLabelEl.style.display = 'none';
    document.getElementById('detail-title').textContent = s.title;
    document.getElementById('detail-desc').textContent = s.desc;
  }

  document.getElementById('detail-icon').innerHTML = `<i class="ti ${s.icon}"></i>`;
  document.getElementById('detail-rating').textContent = `${s.rating.toFixed(1)} (${s.reviews} reviews)`;
  document.getElementById('detail-price').innerHTML = `${s.priceLabel}<span>starting at</span>`;

  document.getElementById('detail-services-section').style.display = showServicesList ? 'block' : 'none';
  document.getElementById('detail-bullets-section').style.display = showBullets ? 'block' : 'none';
  if (showServicesList) {
    document.getElementById('detail-services-list').innerHTML = s.subServices.map(name =>
      `<div class="leafrow" onclick="openServiceDetail(${jsAttr(name)})"><span>${escapeHtml(name)}</span><i class="ti ti-chevron-right"></i></div>`
    ).join('');
  }
}

// Safely embed a JS string literal inside a double-quoted HTML event attribute:
// JSON.stringify handles JS-level quoting/escaping, then we HTML-escape the
// delimiting/embedded double quotes and any raw apostrophes (e.g. "Driver's
// license assistance") so the attribute can't be broken out of.
function jsAttr(value) {
  return JSON.stringify(value)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function closeDetail() {
  document.getElementById('detailview').classList.remove('active');
  detailMode = 'category';
  activeSubService = null;
}

// ---------- booking form ----------
let bookingSubService = null;

function openBookFormFromDetail() {
  openBookForm(activeDetailKey, detailMode === 'service' ? activeSubService : null);
}

async function openBookForm(key, subService) {
  const s = SERVICES_BY_KEY[key];
  if (!s) return;
  if (!TOKEN) { showToast('Please log in to book a service.', true); return; }
  activeDetailKey = key;
  bookingSubService = subService || null;
  document.getElementById('bookform-service-title').textContent = bookingSubService || s.title;
  document.getElementById('bf-price').textContent = s.priceLabel;
  document.getElementById('bf-date').value = '';
  document.getElementById('bf-time').value = '';
  document.getElementById('bf-address').value = '';
  document.getElementById('bf-notes').value = '';
  document.getElementById('bf-error').textContent = '';
  document.getElementById('bookform').classList.add('active');
  await loadPaymentMethods();
  renderBookformPaymentPreview(s);
}

function renderBookformPaymentPreview(s) {
  const el = document.getElementById('bf-payment-preview');
  const submitBtn = document.getElementById('bf-submit');
  if (s.price <= 0) {
    el.innerHTML = `<span>Priced on request — no charge at booking, the provider will quote you directly.</span>`;
    submitBtn.classList.remove('disabled');
    submitBtn.removeAttribute('disabled');
    return;
  }
  const def = paymentMethodsCache.find(p => p.isDefault);
  if (def) {
    el.innerHTML = `<span>Paying with ${def.brand} •••• ${def.last4}</span><a onclick="showTab('payment')">Change</a>`;
    submitBtn.classList.remove('disabled');
    submitBtn.removeAttribute('disabled');
  } else {
    el.innerHTML = `<span style="color:var(--danger);">No payment method on file</span><a onclick="showTab('payment')">Add one</a>`;
    submitBtn.classList.add('disabled');
    submitBtn.setAttribute('disabled', 'true');
  }
}

function closeBookForm() {
  document.getElementById('bookform').classList.remove('active');
}
async function submitBooking() {
  const date = document.getElementById('bf-date').value;
  const time = document.getElementById('bf-time').value;
  const address = document.getElementById('bf-address').value.trim();
  const notes = document.getElementById('bf-notes').value.trim();
  const errEl = document.getElementById('bf-error');
  if (!date || !time || !address) {
    errEl.textContent = 'Please fill in date, time, and address.';
    return;
  }
  errEl.textContent = '';
  try {
    const res = await api('/api/bookings', 'POST', { serviceKey: activeDetailKey, subService: bookingSubService, date, time, address, notes });
    closeBookForm();
    closeDetail();
    if (res.charge && res.charge.status === 'succeeded') {
      showToast(`Booking confirmed — charged ${res.charge.amount.toFixed(2)} JOD to ${res.charge.paymentMethodLabel}.`);
    } else {
      showToast('Booking confirmed — you can track it under Bookings.');
    }
    showTab('bookings');
  } catch (e) {
    errEl.textContent = e.message;
  }
}

// ---------- bookings tab ----------
async function renderBookings() {
  const list = document.getElementById('bookings-list');
  list.innerHTML = '<div class="spinner"></div>';
  try {
    const res = await api('/api/bookings');
    bookingsCache = res.bookings;
  } catch (e) {
    list.innerHTML = `<div class="emptystate">${e.message}</div>`;
    return;
  }

  // Reconcile local GPS watchers with server-known sharing state — this also
  // makes sharing resume automatically after a page reload, since the toggle
  // state lives server-side but the actual watchPosition() call is client-only.
  const activeIds = new Set(bookingsCache.filter(b => b.locationSharing).map(b => b.id));
  Object.keys(locationWatchers).map(Number).forEach(id => { if (!activeIds.has(id)) stopLocationWatch(id); });
  bookingsCache.forEach(b => { if (b.locationSharing) startLocationWatch(b.id); });

  if (bookingsCache.length === 0) {
    list.innerHTML = `<div class="emptystate">No bookings yet — browse services to book your first one.</div>`;
    return;
  }
  const today = new Date().toISOString().slice(0, 10);
  const upcoming = bookingsCache.filter(b => ['pending', 'confirmed', 'en_route'].includes(b.status) && b.date >= today);
  const past = bookingsCache.filter(b => !upcoming.includes(b));

  let html = '';
  if (upcoming.length) html += `<div class="section-label" style="margin-top:0;">Upcoming</div>` + upcoming.map(bookingCardHtml).join('');
  if (past.length) html += `<div class="section-label">Past</div>` + past.map(bookingCardHtml).join('');
  list.innerHTML = html;
}

function bookingCardHtml(b) {
  const canCancel = ['pending', 'confirmed', 'en_route'].includes(b.status);
  const canShare = canCancel; // same set of "still active" statuses
  const statusLabel = { pending: 'PENDING', confirmed: 'CONFIRMED', en_route: 'EN ROUTE', done: 'DONE', cancelled: 'CANCELLED' }[b.status] || b.status.toUpperCase();
  const shareUrl = `${location.origin}/track/${b.trackingToken}`;
  return `<div class="bookingcard">
    <div class="idrow"><span>ID: #${b.id}</span><i class="ti ${b.serviceIcon}"></i></div>
    <h3>${b.serviceTitle}</h3>
    <div class="metarow"><i class="ti ti-calendar-event"></i> ${b.date} · ${b.time}</div>
    <div class="metarow"><i class="ti ti-map-pin"></i> ${escapeHtml(b.address)}</div>
    ${b.provider ? `<div class="metarow"><i class="ti ti-user"></i> ${escapeHtml(b.provider.name)}${b.provider.phone ? ' · ' + escapeHtml(b.provider.phone) : ''}</div>` : ''}
    ${b.notes ? `<div class="notesbox">"${escapeHtml(b.notes)}"</div>` : ''}
    <div class="bottomrow">
      <span class="price">${b.priceLabel}</span>
      <span class="statuspill ${b.status}">${statusLabel}</span>
    </div>
    ${canShare ? `
    <div class="sharerow">
      <div class="sharerow-top">
        <span>Share my live location</span>
        <div class="switch ${b.locationSharing ? 'on' : ''}" onclick="toggleShare(${b.id}, ${b.locationSharing ? 'false' : 'true'})"><div class="knob"></div></div>
      </div>
      ${b.locationSharing ? `
        <div class="sharelink">
          <span class="sharelink-url">${escapeHtml(shareUrl)}</span>
          <span class="sharelink-copy" onclick="copyShareLink(${jsAttr(shareUrl)})">Copy</span>
        </div>
        <div class="sharehint">Send this link to your provider so they can find you.</div>
      ` : ''}
    </div>` : ''}
    ${canCancel ? `<div class="cancellink" onclick="cancelBooking(${b.id})">Cancel booking</div>` : ''}
  </div>`;
}

async function cancelBooking(id) {
  try {
    await api(`/api/bookings/${id}/cancel`, 'PATCH');
    stopLocationWatch(id);
    showToast('Booking cancelled.');
    renderBookings();
  } catch (e) {
    showToast(e.message, true);
  }
}

// ---------- live location sharing ----------
const locationWatchers = {}; // bookingId -> { watchId, lastSentAt }

async function toggleShare(id, enabled) {
  try {
    await api(`/api/bookings/${id}/share`, 'POST', { enabled });
    if (enabled) {
      startLocationWatch(id);
      showToast('Location sharing turned on.');
    } else {
      stopLocationWatch(id);
    }
    renderBookings();
  } catch (e) {
    showToast(e.message, true);
  }
}

function startLocationWatch(id) {
  if (locationWatchers[id]) return;
  if (!navigator.geolocation) {
    showToast('This browser does not support location sharing.', true);
    return;
  }
  const state = { watchId: null, lastSentAt: 0 };
  locationWatchers[id] = state;
  state.watchId = navigator.geolocation.watchPosition(
    (pos) => {
      // Throttle client-side: watchPosition can fire far more often than we
      // want to persist-to-disk on every ping.
      const now = Date.now();
      if (now - state.lastSentAt < 5000) return;
      state.lastSentAt = now;
      api(`/api/bookings/${id}/location`, 'POST', {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
      }).catch(() => {});
    },
    (err) => {
      showToast('Could not get your location: ' + err.message, true);
      stopLocationWatch(id);
    },
    { enableHighAccuracy: false, maximumAge: 10000, timeout: 20000 }
  );
}

function stopLocationWatch(id) {
  const state = locationWatchers[id];
  if (state) {
    navigator.geolocation.clearWatch(state.watchId);
    delete locationWatchers[id];
  }
}

function stopAllLocationWatchers() {
  Object.keys(locationWatchers).map(Number).forEach(stopLocationWatch);
}

function copyShareLink(url) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(() => showToast('Link copied.')).catch(() => showToast('Could not copy link.', true));
  } else {
    showToast('Copy not supported on this browser — select and copy the link manually.', true);
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---------- concierge ----------
async function sendConciergeMessage() {
  const input = document.getElementById('chat-input');
  const message = input.value.trim();
  if (!message) return;
  const log = document.getElementById('chat-log');
  log.innerHTML += `<div class="bubble user">${escapeHtml(message)}</div>`;
  input.value = '';
  log.scrollTop = log.scrollHeight;
  try {
    const res = await api('/api/concierge', 'POST', { message });
    let chips = (res.services || []).map(s =>
      `<span class="chip" onclick="openBookForm('${s.key}')">Book ${s.title}</span>`
    ).join('');
    log.innerHTML += `<div class="bubble ai">${escapeHtml(res.reply)}${chips ? '<br>' + chips : ''}</div>`;
  } catch (e) {
    log.innerHTML += `<div class="bubble ai">Sorry, I couldn't reach the concierge service just now.</div>`;
  }
  log.scrollTop = log.scrollHeight;
}

// ---------- profile ----------
function fillProfileFields() {
  document.getElementById('edit-name').value = CURRENT_USER.name || '';
  document.getElementById('edit-phone').value = CURRENT_USER.phone || '';
}
function toggleProfileEdit() {
  const el = document.getElementById('profile-edit');
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
async function saveProfile() {
  const name = document.getElementById('edit-name').value.trim();
  const phone = document.getElementById('edit-phone').value.trim();
  try {
    const res = await api('/api/me', 'PUT', { name, phone });
    CURRENT_USER = res.user;
    document.getElementById('profile-name').textContent = CURRENT_USER.name;
    document.getElementById('profile-avatar').textContent = CURRENT_USER.name.trim()[0].toUpperCase();
    document.getElementById('profile-edit').style.display = 'none';
    showToast('Profile updated.');
  } catch (e) {
    showToast(e.message, true);
  }
}

// ---------- feedback ----------
let feedbackRating = 0;
function buildStarRow() {
  const row = document.getElementById('star-row');
  row.innerHTML = [1, 2, 3, 4, 5].map(n => `<i class="ti ti-star" data-n="${n}" onclick="setFeedbackRating(${n})"></i>`).join('');
}
function setFeedbackRating(n) {
  feedbackRating = n;
  document.querySelectorAll('#star-row i').forEach(i => {
    const filled = Number(i.dataset.n) <= n;
    i.className = filled ? 'ti ti-star-filled' : 'ti ti-star';
  });
}
async function submitFeedback() {
  const message = document.getElementById('feedback-text').value.trim();
  try {
    await api('/api/feedback', 'POST', { rating: feedbackRating || null, message });
    document.getElementById('feedback-text').value = '';
    setFeedbackRating(0);
    showToast('Thanks — your feedback was submitted.');
  } catch (e) {
    showToast(e.message, true);
  }
}

// ---------- toast ----------
let toastTimer = null;
function showToast(msg, isError) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast show' + (isError ? ' error' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.classList.remove('show'); }, 3000);
}

document.addEventListener('DOMContentLoaded', init);
