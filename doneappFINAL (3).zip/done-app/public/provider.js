let TOKEN = localStorage.getItem('done_provider_token') || null;
let CURRENT_USER = null;
let SERVICES = [];
let CATEGORIES = [];
let authMode = 'login';

async function api(path, method = 'GET', body) {
  const headers = { 'Content-Type': 'application/json' };
  if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;
  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function init() {
  try {
    const catRes = await api('/api/categories');
    CATEGORIES = catRes.categories.filter(c => c.id !== 'vip');
    const svcRes = await api('/api/services');
    SERVICES = svcRes.services;
  } catch (e) {
    showToast('Could not reach the server. Is it running?', true);
    return;
  }

  buildCategoryPicker('category-picker');
  buildCategoryPicker('profile-category-picker');

  if (TOKEN) {
    try {
      const me = await api('/api/me');
      if (me.user.role !== 'provider') throw new Error('not a provider account');
      CURRENT_USER = me.user;
      showDashboard();
    } catch (e) {
      TOKEN = null;
      localStorage.removeItem('done_provider_token');
      showAuth();
    }
  } else {
    showAuth();
  }
}

function buildCategoryPicker(containerId) {
  const el = document.getElementById(containerId);
  el.innerHTML = CATEGORIES.map(group => {
    const items = SERVICES.filter(s => s.category === group.id);
    return `<div class="categorygroup">${escapeHtml(group.label)}</div>` +
      items.map(s => `<label class="categorycheck"><input type="checkbox" value="${s.key}"> ${escapeHtml(s.title)}</label>`).join('');
  }).join('');
}

function getCheckedCategories(containerId) {
  return [...document.querySelectorAll(`#${containerId} input:checked`)].map(el => el.value);
}
function setCheckedCategories(containerId, keys) {
  const set = new Set(keys || []);
  document.querySelectorAll(`#${containerId} input`).forEach(el => { el.checked = set.has(el.value); });
}

function showAuth() {
  document.getElementById('authscreen').style.display = 'block';
  document.getElementById('dashboard').style.display = 'none';
  document.getElementById('topbar-user').style.display = 'none';
}

function showDashboard() {
  document.getElementById('authscreen').style.display = 'none';
  document.getElementById('dashboard').style.display = 'block';
  document.getElementById('topbar-user').style.display = 'flex';
  document.getElementById('topbar-name').textContent = CURRENT_USER.name;
  document.getElementById('profile-name').value = CURRENT_USER.name || '';
  document.getElementById('profile-phone').value = CURRENT_USER.phone || '';
  document.getElementById('profile-bio').value = CURRENT_USER.bio || '';
  setCheckedCategories('profile-category-picker', CURRENT_USER.categories);
  connectEvents();
  showProviderTab('available');
}

// ---------- real-time updates (Server-Sent Events) ----------
let eventSource = null;
function connectEvents() {
  if (eventSource) eventSource.close();
  eventSource = new EventSource(`/api/events?token=${encodeURIComponent(TOKEN)}`);
  const refreshAvailable = () => { if (document.getElementById('panel-available').classList.contains('active')) loadAvailableJobs(); };
  const refreshMine = () => { if (document.getElementById('panel-mine').classList.contains('active')) loadMyJobs(); };
  eventSource.addEventListener('job-available', refreshAvailable);
  eventSource.addEventListener('job-taken', refreshAvailable);
  eventSource.addEventListener('booking-updated', refreshMine);
  eventSource.addEventListener('location-updated', refreshMine);
}
function disconnectEvents() {
  if (eventSource) { eventSource.close(); eventSource = null; }
}

function setAuthMode(mode) {
  authMode = mode;
  document.getElementById('tab-login').classList.toggle('active', mode === 'login');
  document.getElementById('tab-signup').classList.toggle('active', mode === 'signup');
  document.getElementById('signup-fields').style.display = mode === 'signup' ? 'block' : 'none';
  document.getElementById('auth-password-field').style.display = mode === 'forgot' ? 'none' : 'block';
  document.getElementById('forgot-hint').style.display = mode === 'login' ? 'block' : 'none';
  document.getElementById('auth-success').style.display = 'none';
  document.getElementById('auth-submit').textContent = mode === 'signup' ? 'Create account' : mode === 'forgot' ? 'Send reset link' : 'Log in';
  document.getElementById('auth-hint').innerHTML = mode === 'signup'
    ? 'Already registered? <a onclick="setAuthMode(\'login\')">Log in</a>'
    : mode === 'forgot'
    ? 'Remembered it? <a onclick="setAuthMode(\'login\')">Log in</a>'
    : 'New provider? <a onclick="setAuthMode(\'signup\')">Create an account</a>';
  document.getElementById('auth-error').textContent = '';
}

async function submitAuth() {
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const errEl = document.getElementById('auth-error');
  errEl.textContent = '';
  try {
    if (authMode === 'forgot') {
      await api('/api/auth/forgot-password', 'POST', { email });
      const successEl = document.getElementById('auth-success');
      successEl.style.display = 'block';
      successEl.textContent = "If that email has an account, we've sent a reset link.";
      return;
    }
    let res;
    if (authMode === 'signup') {
      const name = document.getElementById('su-name').value.trim();
      const phone = document.getElementById('su-phone').value.trim();
      const bio = document.getElementById('su-bio').value.trim();
      const categories = getCheckedCategories('category-picker');
      if (!name) { errEl.textContent = 'Please enter your name.'; return; }
      if (categories.length === 0) { errEl.textContent = 'Select at least one service you provide.'; return; }
      res = await api('/api/auth/signup', 'POST', { name, email, phone, password, role: 'provider', categories, bio });
    } else {
      res = await api('/api/auth/login', 'POST', { email, password });
      if (res.user.role !== 'provider') {
        errEl.textContent = 'This account is not a provider account.';
        return;
      }
    }
    TOKEN = res.token;
    CURRENT_USER = res.user;
    localStorage.setItem('done_provider_token', TOKEN);
    showDashboard();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function logout() {
  disconnectEvents();
  try { await api('/api/auth/logout', 'POST'); } catch (e) {}
  TOKEN = null;
  CURRENT_USER = null;
  localStorage.removeItem('done_provider_token');
  showAuth();
}

function showProviderTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
  document.querySelectorAll('.tabpanel').forEach(p => p.classList.remove('active'));
  document.getElementById('panel-' + tab).classList.add('active');
  if (tab === 'available') loadAvailableJobs();
  if (tab === 'mine') loadMyJobs();
}

async function loadAvailableJobs() {
  const list = document.getElementById('available-list');
  list.innerHTML = '<div class="spinner"></div>';
  try {
    const res = await api('/api/provider/jobs/available');
    if (res.jobs.length === 0) {
      list.innerHTML = `<div class="emptystate">No available jobs match the services you offer right now — check back soon.</div>`;
      return;
    }
    list.innerHTML = res.jobs.map(j => jobCardHtml(j, 'available')).join('');
  } catch (e) {
    list.innerHTML = `<div class="emptystate">${escapeHtml(e.message)}</div>`;
  }
}

async function loadMyJobs() {
  const list = document.getElementById('mine-list');
  list.innerHTML = '<div class="spinner"></div>';
  try {
    const res = await api('/api/provider/jobs/mine');
    if (res.jobs.length === 0) {
      list.innerHTML = `<div class="emptystate">You haven't accepted any jobs yet.</div>`;
      return;
    }
    list.innerHTML = res.jobs.map(j => jobCardHtml(j, 'mine')).join('');
  } catch (e) {
    list.innerHTML = `<div class="emptystate">${escapeHtml(e.message)}</div>`;
  }
}

const STATUS_LABEL = { pending: 'PENDING', confirmed: 'CONFIRMED', en_route: 'EN ROUTE', done: 'DONE', cancelled: 'CANCELLED' };
const NEXT_STATUS = { confirmed: { next: 'en_route', label: 'Mark en route' }, en_route: { next: 'done', label: 'Mark done' } };

function jobCardHtml(j, mode) {
  const statusLabel = STATUS_LABEL[j.status] || j.status.toUpperCase();
  const nextAction = NEXT_STATUS[j.status];
  let actions = '';
  if (mode === 'available') {
    actions = `<div class="actions"><button class="btn primary" onclick="acceptJob(${j.id})">Accept job</button></div>`;
  } else if (mode === 'mine') {
    const buttons = [];
    if (nextAction) buttons.push(`<button class="btn primary" onclick="setJobStatus(${j.id}, '${nextAction.next}')">${nextAction.label}</button>`);
    if (j.status === 'confirmed') buttons.push(`<button class="btn outline" onclick="releaseJob(${j.id})">Release job</button>`);
    actions = buttons.length ? `<div class="actions">${buttons.join('')}</div>` : '';
  }
  return `<div class="jobcard">
    <div class="jobtop">
      <div>
        <h3>${escapeHtml(j.subService || j.serviceTitle)}</h3>
        ${j.subService ? `<div class="metarow" style="margin-top:2px;"><i class="ti ${j.serviceIcon}"></i>${escapeHtml(j.serviceTitle)}</div>` : ''}
      </div>
      <span class="statuspill ${j.status}">${statusLabel}</span>
    </div>
    <div class="metarow"><i class="ti ti-calendar-event"></i>${escapeHtml(j.date)} · ${escapeHtml(j.time)}</div>
    <div class="metarow"><i class="ti ti-map-pin"></i>${escapeHtml(j.address)}</div>
    ${j.customer ? `<div class="metarow"><i class="ti ti-user"></i>${escapeHtml(j.customer.name)}${j.customer.phone ? ' · ' + escapeHtml(j.customer.phone) : ''}</div>` : ''}
    <div class="metarow"><i class="ti ti-tag"></i><span class="price">${j.priceLabel}</span></div>
    ${j.notes ? `<div class="notes">"${escapeHtml(j.notes)}"</div>` : ''}
    ${j.locationSharing && j.location ? `<div class="locbox"><span>Live location: ${j.location.lat.toFixed(5)}, ${j.location.lng.toFixed(5)}</span><a target="_blank" rel="noopener" href="https://www.google.com/maps?q=${j.location.lat},${j.location.lng}">Open in Maps</a></div>` : ''}
    ${j.locationSharing && !j.location ? `<div class="locbox"><span>Customer is sharing — waiting for a location fix…</span></div>` : ''}
    ${actions}
  </div>`;
}

async function acceptJob(id) {
  try {
    await api(`/api/provider/jobs/${id}/accept`, 'POST');
    showToast('Job accepted — find it under "My jobs".');
    loadAvailableJobs();
  } catch (e) {
    showToast(e.message, true);
    loadAvailableJobs(); // someone else may have taken it — refresh the list
  }
}

async function releaseJob(id) {
  try {
    await api(`/api/provider/jobs/${id}/release`, 'POST');
    showToast('Job released back to the available pool.');
    loadMyJobs();
  } catch (e) {
    showToast(e.message, true);
  }
}

async function setJobStatus(id, status) {
  try {
    await api(`/api/provider/jobs/${id}/status`, 'PATCH', { status });
    showToast(status === 'done' ? 'Job marked done.' : 'Status updated.');
    loadMyJobs();
  } catch (e) {
    showToast(e.message, true);
  }
}

async function saveProfile() {
  const name = document.getElementById('profile-name').value.trim();
  const phone = document.getElementById('profile-phone').value.trim();
  const bio = document.getElementById('profile-bio').value.trim();
  const categories = getCheckedCategories('profile-category-picker');
  const errEl = document.getElementById('profile-error');
  if (categories.length === 0) { errEl.textContent = 'Select at least one service you provide.'; return; }
  errEl.textContent = '';
  try {
    const res = await api('/api/me', 'PUT', { name, phone, bio, categories });
    CURRENT_USER = res.user;
    document.getElementById('topbar-name').textContent = CURRENT_USER.name;
    showToast('Profile saved.');
  } catch (e) {
    errEl.textContent = e.message;
  }
}

let toastTimer = null;
function showToast(msg, isError) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast show' + (isError ? ' error' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.classList.remove('show'); }, 3500);
}

document.addEventListener('DOMContentLoaded', init);
