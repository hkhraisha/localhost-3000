// "Done" — home services booking app
// Pure Node.js backend, zero npm dependencies. Storage is SQLite via Node's
// own built-in `node:sqlite` (see data/db.js) — real transactions/indexes/
// constraints instead of a hand-rolled JSON file, with automatic periodic
// backups (VACUUM INTO snapshots, see data/db.js's snapshotBackup).

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const url = require('url');

const { SERVICES, CATEGORIES } = require('./data/services.js');
const { Users, Categories, Sessions, PasswordResets, Bookings, PaymentMethods, Charges, Feedback, snapshotBackup } = require('./data/db.js');
const { sendMail } = require('./lib/smtp.js');
const { conciergeComplete } = require('./lib/anthropic.js');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || null;
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const RESET_TTL_MS = 60 * 60 * 1000; // 1 hour

// SMTP config for password-reset emails — all via env vars, nothing hardcoded.
// See README for setup (a Gmail App Password, not your real account password).
const SMTP_HOST = process.env.SMTP_HOST || 'smtp.gmail.com';
const SMTP_PORT = Number(process.env.SMTP_PORT || 465);
const SMTP_USER = process.env.SMTP_USER || null;
const SMTP_PASS = process.env.SMTP_PASS || null;
const SMTP_FROM = process.env.SMTP_FROM || SMTP_USER;
const emailConfigured = !!(SMTP_USER && SMTP_PASS);

setInterval(snapshotBackup, 30 * 60 * 1000);
setInterval(() => { Sessions.deleteExpired(); PasswordResets.deleteExpired(); }, 60 * 60 * 1000);

// ---------- password hashing (scrypt, built into node crypto) ----------

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(check, 'hex'));
}

function makeToken() {
  return crypto.randomBytes(24).toString('hex');
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || ''));
}

// ---------- basic rate limiting (in-memory, per client IP) ----------
// Intentionally simple — mitigates casual brute-forcing of login/signup, not
// a substitute for a real WAF/reverse-proxy rate limiter in front of this.

const rateLimitBuckets = new Map(); // key -> timestamps[]
const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;
const RATE_LIMIT_MAX = 10;

function rateLimited(key) {
  const now = Date.now();
  const fresh = (rateLimitBuckets.get(key) || []).filter(t => now - t < RATE_LIMIT_WINDOW_MS);
  fresh.push(now);
  rateLimitBuckets.set(key, fresh);
  return fresh.length > RATE_LIMIT_MAX;
}
setInterval(() => {
  const now = Date.now();
  for (const [key, arr] of rateLimitBuckets) {
    const fresh = arr.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
    if (fresh.length === 0) rateLimitBuckets.delete(key);
    else rateLimitBuckets.set(key, fresh);
  }
}, 10 * 60 * 1000);

function clientKey(req) {
  return req.socket.remoteAddress || 'unknown';
}

// ---------- mock payment processor ----------
// Fully self-contained — no external service, no API keys, no real money
// ever moves. Card numbers are validated and tokenized the same way a real
// processor would (Luhn check, brand detection, then the PAN/CVC are
// discarded — only last4/brand/expiry are ever persisted). Charge behavior
// is keyed off a handful of well-known Stripe test-mode card numbers, so if
// this is ever swapped for real Stripe test mode later, the same numbers
// used to test success/decline paths here keep behaving the same way.

function luhnValid(number) {
  const digits = number.replace(/\D/g, '');
  if (digits.length < 12 || digits.length > 19) return false;
  let sum = 0;
  let alternate = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = parseInt(digits[i], 10);
    if (alternate) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
    alternate = !alternate;
  }
  return sum % 10 === 0;
}

function detectBrand(number) {
  const d = number.replace(/\D/g, '');
  if (/^4/.test(d)) return 'visa';
  if (/^5[1-5]/.test(d) || /^2(2[2-9][1-9]|2[3-9]\d\d|[3-6]\d{3}|7[01]\d\d|720\d)/.test(d)) return 'mastercard';
  if (/^3[47]/.test(d)) return 'amex';
  if (/^6(?:011|5)/.test(d)) return 'discover';
  return 'card';
}

const TEST_DECLINE_BEHAVIOR = {
  '4000000000000002': 'Your card was declined.',
  '4000000000009995': 'Your card has insufficient funds.',
  '4000000000000069': 'Your card has expired.',
  '4000000000000127': "Your card's security code is incorrect.",
};

function validateAndTokenizeCard({ cardNumber, expMonth, expYear, cvc, name }) {
  const digits = String(cardNumber || '').replace(/\D/g, '');
  if (!name || !String(name).trim()) return { error: 'Name on card is required.' };
  if (!digits || !luhnValid(digits)) return { error: 'Card number is invalid.' };
  const month = Number(expMonth);
  const year = Number(expYear);
  if (!Number.isInteger(month) || month < 1 || month > 12) return { error: 'Expiry month is invalid.' };
  if (!Number.isInteger(year)) return { error: 'Expiry year is invalid.' };
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  if (year < currentYear || (year === currentYear && month < currentMonth)) {
    return { error: 'This card has expired.' };
  }
  const brand = detectBrand(digits);
  const cvcLen = brand === 'amex' ? 4 : 3;
  if (!/^\d+$/.test(String(cvc || '')) || String(cvc).length !== cvcLen) {
    return { error: `Security code must be ${cvcLen} digits.` };
  }
  return {
    brand,
    last4: digits.slice(-4),
    expMonth: month,
    expYear: year,
    name: String(name).trim(),
    declineReason: TEST_DECLINE_BEHAVIOR[digits] || null,
  };
}

function chargePaymentMethod(pm) {
  if (pm.declineReason) return { status: 'declined', reason: pm.declineReason };
  return { status: 'succeeded' };
}

function publicPaymentMethod(pm) {
  return { id: pm.id, brand: pm.brand, last4: pm.last4, expMonth: pm.expMonth, expYear: pm.expYear, isDefault: pm.isDefault, createdAt: pm.createdAt };
}

// ---------- request helpers ----------

function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 1_000_000) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (chunks.length === 0) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch (e) {
        reject(new Error('invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

// requiredRole: undefined = any authenticated user, 'customer'|'provider' = must match
function getAuthUser(req, requiredRole) {
  const header = req.headers['authorization'] || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return null;
  const session = Sessions.get(token);
  if (!session) return null;
  const user = Users.findById(session.userId);
  if (!user) return null;
  if (requiredRole && user.role !== requiredRole) return null;
  return { user, token };
}

function publicUser(u) {
  const base = { id: u.id, role: u.role, name: u.name, email: u.email, phone: u.phone || '', createdAt: u.createdAt };
  if (u.role === 'provider') {
    base.categories = u.categories || [];
    base.bio = u.bio || '';
  }
  return base;
}

function publicContact(u) {
  return u ? { name: u.name, phone: u.phone || '' } : null;
}

function publicBookingForCustomer(b) {
  return { ...b, provider: b.providerId ? publicContact(Users.findById(b.providerId)) : null };
}

function publicBookingForProvider(b, revealContact) {
  const customer = Users.findById(b.userId);
  return {
    id: b.id, serviceKey: b.serviceKey, subService: b.subService, serviceTitle: b.serviceTitle,
    serviceIcon: b.serviceIcon, price: b.price, priceLabel: b.priceLabel,
    date: b.date, time: b.time, address: b.address,
    notes: revealContact ? (b.notes || '') : '',
    status: b.status, createdAt: b.createdAt,
    customer: revealContact ? publicContact(customer) : null,
    locationSharing: revealContact ? b.locationSharing : false,
    location: revealContact && b.locationSharing ? b.location : null,
  };
}

// ---------- real-time push (Server-Sent Events, no external deps) ----------

const sseClients = new Set(); // { res, userId, role, categories }

function sseSend(client, event, data) {
  try {
    client.res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  } catch (e) {
    sseClients.delete(client);
  }
}

function notifyCustomer(userId, event, data) {
  for (const c of sseClients) if (c.role === 'customer' && c.userId === userId) sseSend(c, event, data);
}
function notifyProvider(userId, event, data) {
  for (const c of sseClients) if (c.role === 'provider' && c.userId === userId) sseSend(c, event, data);
}
function broadcastToMatchingProviders(serviceKey, event, data) {
  for (const c of sseClients) {
    if (c.role === 'provider' && (c.categories || []).includes(serviceKey)) sseSend(c, event, data);
  }
}
setInterval(() => {
  for (const c of sseClients) sseSend(c, 'ping', {});
}, 25000);

// ---------- static file serving ----------

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function serveStatic(req, res, pathname) {
  let filePath = pathname === '/' ? '/index.html' : pathname;
  filePath = path.join(PUBLIC_DIR, filePath);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (err2, data2) => {
        if (err2) { res.writeHead(404); res.end('Not found'); return; }
        res.writeHead(200, { 'Content-Type': MIME['.html'] });
        res.end(data2);
      });
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

// ---------- concierge ----------
// Uses the real Claude API when ANTHROPIC_API_KEY is set (see lib/anthropic.js);
// falls back to a rule-based keyword matcher otherwise — and falls back to it
// live, per-request, if the API call fails for any reason (network issue, bad
// key, rate limit), so a concierge problem never breaks the chat entirely.

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || null;
const VALID_SERVICE_KEYS = SERVICES.map(s => s.key);
// Compact enough to stay a reasonable system-prompt size across 44 categories.
const CATALOG_SUMMARY = SERVICES.map(s => `- ${s.key} (${s.title}, ${s.priceLabel}): ${s.subServices.length ? s.subServices.join(', ') : s.desc}`).join('\n');

const KEYWORDS = {
  cleaning: ['clean', 'dirty', 'dust', 'mess', 'tidy'],
  plumbing: ['leak', 'pipe', 'clog', 'plumb', 'toilet', 'faucet', 'drain'],
  electric: ['wiring', 'outlet', 'electric', 'power', 'circuit', 'breaker'],
  ac: ['ac ', 'a/c', 'air condition', 'cooling', 'cool', 'hot', 'hvac'],
  appliance: ['fridge', 'refrigerator', 'washer', 'washing machine', 'dryer', 'dishwasher', 'oven', 'microwave'],
  physician: ['sick', 'fever', 'doctor', 'ill', 'pain', 'medicine', 'prescription'],
  massage: ['massage', 'sore', 'stress', 'relax', 'spa'],
  automotive: ['ride', 'drive', 'driver', 'pickup', 'car service'],
  petcare: ['dog', 'cat', 'pet', 'walk my'],
  beauty: ['hair', 'nails', 'makeup', 'salon'],
  childfamily: ['babysit', 'nanny', 'kids', 'children'],
  emergency: ['emergency', 'urgent', 'locked out', 'locksmith', 'flood', 'fire damage'],
  pestcontrol: ['bugs', 'ants', 'roach', 'rodent', 'mice', 'pest'],
  painting: ['paint', 'wall color'],
  carpentry: ['furniture', 'assemble', 'shelf', 'cabinet'],
};

function keywordConciergeReply(message) {
  const text = message.toLowerCase();
  let matchedKeys = new Set();
  for (const [key, words] of Object.entries(KEYWORDS)) {
    if (words.some(w => text.includes(w))) matchedKeys.add(key);
  }
  const matches = SERVICES.filter(s => matchedKeys.has(s.key)).slice(0, 3);

  if (matches.length === 0) {
    return {
      reply: "I can help with that — here are a few popular services to start from, or try browsing all categories.",
      services: SERVICES.filter(s => ['cleaning', 'physician', 'electric'].includes(s.key)),
    };
  }
  const names = matches.map(m => m.title).join(', ');
  return {
    reply: `That sounds like it fits: ${names}. I've found vetted professionals for this — want to book the soonest one?`,
    services: matches,
  };
}

async function conciergeReply(message) {
  if (!ANTHROPIC_API_KEY) return keywordConciergeReply(message);
  try {
    const result = await conciergeComplete({
      apiKey: ANTHROPIC_API_KEY,
      message,
      catalogSummary: CATALOG_SUMMARY,
      validServiceKeys: VALID_SERVICE_KEYS,
    });
    const services = result.serviceKeys.map(k => SERVICES.find(s => s.key === k)).filter(Boolean);
    return { reply: result.reply, services };
  } catch (e) {
    console.error('Claude API concierge call failed, falling back to keyword matching:', e.message);
    return keywordConciergeReply(message);
  }
}

// ---------- route handling ----------

async function handleApi(req, res, pathname) {
  const method = req.method;

  // ----- auth (shared signup/login for both customer and provider accounts) -----
  if (pathname === '/api/auth/signup' && method === 'POST') {
    if (rateLimited('signup:' + clientKey(req))) return sendJSON(res, 429, { error: 'Too many attempts. Try again later.' });
    const body = await readBody(req);
    const { name, email, phone, password, role, categories, bio } = body;
    if (!name || !email || !password) return sendJSON(res, 400, { error: 'name, email, and password are required' });
    if (!isValidEmail(email)) return sendJSON(res, 400, { error: 'Please enter a valid email address.' });
    if (String(password).length < 8) return sendJSON(res, 400, { error: 'Password must be at least 8 characters.' });
    if (Users.findByEmail(email)) return sendJSON(res, 409, { error: 'An account with this email already exists' });

    const isProvider = role === 'provider';
    let providerCategories = [];
    if (isProvider) {
      providerCategories = Array.isArray(categories) ? categories.filter(c => SERVICES.some(s => s.key === c)) : [];
      if (providerCategories.length === 0) return sendJSON(res, 400, { error: 'Select at least one service you provide.' });
    }
    const user = Users.create({
      role: isProvider ? 'provider' : 'customer',
      name, email, phone: phone || '',
      passwordHash: hashPassword(password),
      bio: isProvider ? String(bio || '').slice(0, 500) : '',
      categories: providerCategories,
    });
    const token = makeToken();
    Sessions.create(token, user.id, Date.now() + SESSION_TTL_MS);
    return sendJSON(res, 201, { token, user: publicUser(user) });
  }

  if (pathname === '/api/auth/login' && method === 'POST') {
    if (rateLimited('login:' + clientKey(req))) return sendJSON(res, 429, { error: 'Too many attempts. Try again later.' });
    const body = await readBody(req);
    const { email, password } = body;
    const user = Users.findByEmail(email || '');
    if (!user || !verifyPassword(password || '', user.passwordHash)) {
      return sendJSON(res, 401, { error: 'Invalid email or password' });
    }
    const token = makeToken();
    Sessions.create(token, user.id, Date.now() + SESSION_TTL_MS);
    return sendJSON(res, 200, { token, user: publicUser(user) });
  }

  if (pathname === '/api/auth/logout' && method === 'POST') {
    const auth = getAuthUser(req);
    if (auth) Sessions.delete(auth.token);
    return sendJSON(res, 200, { ok: true });
  }

  // ----- password reset -----
  // Always responds 200 regardless of whether the email exists, so this
  // can't be used to enumerate registered accounts. Requires SMTP_USER/
  // SMTP_PASS to actually be configured — otherwise it's a safe no-op
  // (logged clearly) rather than pretending to send something it didn't.
  if (pathname === '/api/auth/forgot-password' && method === 'POST') {
    if (rateLimited('forgot:' + clientKey(req))) return sendJSON(res, 429, { error: 'Too many attempts. Try again later.' });
    const body = await readBody(req);
    const user = Users.findByEmail(body.email || '');
    if (user) {
      const token = makeToken();
      PasswordResets.create(token, user.id, Date.now() + RESET_TTL_MS);
      const base = process.env.APP_BASE_URL || `http://${req.headers.host}`;
      const resetUrl = `${base}/reset-password.html?token=${token}`;
      if (emailConfigured) {
        try {
          await sendMail({
            host: SMTP_HOST, port: SMTP_PORT, user: SMTP_USER, pass: SMTP_PASS,
            from: SMTP_FROM, to: user.email,
            subject: 'Reset your Done password',
            text: `Hi ${user.name},\n\nSomeone requested a password reset for your Done account. This link is valid for 1 hour:\n\n${resetUrl}\n\nIf you didn't request this, you can ignore this email — your password won't change.\n`,
          });
        } catch (e) {
          console.error('Password reset email failed to send:', e.message);
        }
      } else {
        console.warn(`SMTP not configured — password reset link for ${user.email}: ${resetUrl}`);
      }
    }
    return sendJSON(res, 200, { ok: true });
  }

  if (pathname === '/api/auth/reset-password' && method === 'POST') {
    const body = await readBody(req);
    const { token, password } = body;
    if (!token || !password) return sendJSON(res, 400, { error: 'token and password are required' });
    if (String(password).length < 8) return sendJSON(res, 400, { error: 'Password must be at least 8 characters.' });
    const reset = PasswordResets.get(token);
    if (!reset || reset.used || reset.expiresAt < Date.now()) {
      return sendJSON(res, 400, { error: 'This reset link is invalid or has expired. Request a new one.' });
    }
    Users.setPasswordHash(reset.userId, hashPassword(password));
    PasswordResets.markUsed(token);
    Sessions.deleteAllForUser(reset.userId); // force re-login everywhere, in case the account was compromised
    return sendJSON(res, 200, { ok: true });
  }

  // ----- profile -----
  if (pathname === '/api/me' && method === 'GET') {
    const auth = getAuthUser(req);
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    return sendJSON(res, 200, { user: publicUser(auth.user) });
  }

  if (pathname === '/api/me' && method === 'PUT') {
    const auth = getAuthUser(req);
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    const body = await readBody(req);
    Users.update(auth.user.id, {
      name: body.name,
      phone: body.phone,
      bio: auth.user.role === 'provider' && body.bio !== undefined ? String(body.bio).slice(0, 500) : undefined,
    });
    if (auth.user.role === 'provider' && Array.isArray(body.categories)) {
      const valid = body.categories.filter(c => SERVICES.some(s => s.key === c));
      if (valid.length > 0) Categories.setForProvider(auth.user.id, valid);
    }
    return sendJSON(res, 200, { user: publicUser(Users.findById(auth.user.id)) });
  }

  // ----- payment methods (customers only) -----
  if (pathname === '/api/payment-methods' && method === 'GET') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    return sendJSON(res, 200, { paymentMethods: PaymentMethods.findByUser(auth.user.id).map(publicPaymentMethod) });
  }

  if (pathname === '/api/payment-methods' && method === 'POST') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    const body = await readBody(req);
    const result = validateAndTokenizeCard(body);
    if (result.error) return sendJSON(res, 400, { error: result.error });
    const pm = PaymentMethods.create({
      userId: auth.user.id, brand: result.brand, last4: result.last4,
      expMonth: result.expMonth, expYear: result.expYear, name: result.name,
      declineReason: result.declineReason,
    });
    return sendJSON(res, 201, { paymentMethod: publicPaymentMethod(pm) });
  }

  const setDefaultMatch = pathname.match(/^\/api\/payment-methods\/(\d+)\/default$/);
  if (setDefaultMatch && method === 'PATCH') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    const pm = PaymentMethods.findById(Number(setDefaultMatch[1]), auth.user.id);
    if (!pm) return sendJSON(res, 404, { error: 'Payment method not found' });
    const updated = PaymentMethods.setDefault(auth.user.id, pm.id);
    return sendJSON(res, 200, { paymentMethod: publicPaymentMethod(updated) });
  }

  const deletePmMatch = pathname.match(/^\/api\/payment-methods\/(\d+)$/);
  if (deletePmMatch && method === 'DELETE') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    const ok = PaymentMethods.delete(Number(deletePmMatch[1]), auth.user.id);
    if (!ok) return sendJSON(res, 404, { error: 'Payment method not found' });
    return sendJSON(res, 200, { ok: true });
  }

  if (pathname === '/api/billing-history' && method === 'GET') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    return sendJSON(res, 200, { charges: Charges.findByUser(auth.user.id) });
  }

  // ----- services -----
  if (pathname === '/api/categories' && method === 'GET') {
    return sendJSON(res, 200, { categories: CATEGORIES });
  }

  if (pathname === '/api/services' && method === 'GET') {
    const { query } = url.parse(req.url, true);
    let list = SERVICES;
    if (query.category) list = list.filter(s => s.category === query.category);
    if (query.q) {
      const q = String(query.q).toLowerCase();
      list = list.filter(s => s.title.toLowerCase().includes(q) || s.desc.toLowerCase().includes(q) || s.subServices.some(n => n.toLowerCase().includes(q)));
    }
    return sendJSON(res, 200, { services: list });
  }

  const serviceMatch = pathname.match(/^\/api\/services\/([a-zA-Z0-9_-]+)$/);
  if (serviceMatch && method === 'GET') {
    const service = SERVICES.find(s => s.key === serviceMatch[1]);
    if (!service) return sendJSON(res, 404, { error: 'Service not found' });
    return sendJSON(res, 200, { service });
  }

  // ----- bookings (customers only — a provider account books nothing) -----
  if (pathname === '/api/bookings' && method === 'POST') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Please sign in as a customer to book a service' });
    const body = await readBody(req);
    const { serviceKey, subService, date, time, address, notes } = body;
    const service = SERVICES.find(s => s.key === serviceKey);
    if (!service) return sendJSON(res, 400, { error: 'Unknown service' });
    if (subService && !service.subServices.includes(subService)) {
      return sendJSON(res, 400, { error: 'Unknown service option' });
    }
    if (!date || !time || !address) return sendJSON(res, 400, { error: 'date, time, and address are required' });

    let charge = null;
    if (service.price > 0) {
      const pm = PaymentMethods.findDefault(auth.user.id);
      if (!pm) return sendJSON(res, 400, { error: 'Add a payment method before booking.', code: 'no_payment_method' });
      const result = chargePaymentMethod(pm);
      charge = Charges.create({
        userId: auth.user.id, bookingId: null, paymentMethodId: pm.id,
        paymentMethodLabel: `${pm.brand} •••• ${pm.last4}`, amount: service.price, currency: 'JOD',
        status: result.status, reason: result.reason || null, serviceTitle: subService || service.title,
      });
      if (result.status !== 'succeeded') {
        return sendJSON(res, 402, { error: result.reason, code: 'card_declined' });
      }
    }

    const booking = Bookings.create({
      userId: auth.user.id, serviceKey, subService: subService || null,
      serviceTitle: subService || service.title, serviceIcon: service.icon,
      price: service.price, priceLabel: service.priceLabel,
      date, time, address, notes: notes || '', status: 'pending',
      createdAt: new Date().toISOString(), trackingToken: makeToken(),
      paymentStatus: service.price > 0 ? 'paid' : 'not_required',
      chargeId: charge ? charge.id : null,
    });
    if (charge) Bookings.setChargeId(booking.id, charge.id);
    broadcastToMatchingProviders(booking.serviceKey, 'job-available', { bookingId: booking.id });
    return sendJSON(res, 201, { booking: publicBookingForCustomer(Bookings.findById(booking.id)), charge });
  }

  if (pathname === '/api/bookings' && method === 'GET') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    return sendJSON(res, 200, { bookings: Bookings.findByUser(auth.user.id).map(publicBookingForCustomer) });
  }

  const cancelMatch = pathname.match(/^\/api\/bookings\/(\d+)\/cancel$/);
  if (cancelMatch && method === 'PATCH') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    const booking = Bookings.findById(Number(cancelMatch[1]));
    if (!booking || booking.userId !== auth.user.id) return sendJSON(res, 404, { error: 'Booking not found' });
    const updated = Bookings.cancel(booking.id);
    if (booking.providerId) notifyProvider(booking.providerId, 'booking-updated', { bookingId: booking.id });
    return sendJSON(res, 200, { booking: publicBookingForCustomer(updated) });
  }

  // ----- live location sharing -----
  const shareMatch = pathname.match(/^\/api\/bookings\/(\d+)\/share$/);
  if (shareMatch && method === 'POST') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    const booking = Bookings.findById(Number(shareMatch[1]));
    if (!booking || booking.userId !== auth.user.id) return sendJSON(res, 404, { error: 'Booking not found' });
    if (['done', 'cancelled'].includes(booking.status)) {
      return sendJSON(res, 400, { error: 'This booking is no longer active' });
    }
    const body = await readBody(req);
    const updated = Bookings.setLocationSharing(booking.id, !!body.enabled);
    if (booking.providerId) notifyProvider(booking.providerId, 'booking-updated', { bookingId: booking.id });
    return sendJSON(res, 200, { locationSharing: updated.locationSharing, trackingToken: updated.trackingToken });
  }

  const locationMatch = pathname.match(/^\/api\/bookings\/(\d+)\/location$/);
  if (locationMatch && method === 'POST') {
    const auth = getAuthUser(req, 'customer');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated' });
    const booking = Bookings.findById(Number(locationMatch[1]));
    if (!booking || booking.userId !== auth.user.id) return sendJSON(res, 404, { error: 'Booking not found' });
    if (!booking.locationSharing) return sendJSON(res, 400, { error: 'Location sharing is not enabled for this booking' });
    const body = await readBody(req);
    const lat = Number(body.lat);
    const lng = Number(body.lng);
    if (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lng) || lng < -180 || lng > 180) {
      return sendJSON(res, 400, { error: 'lat/lng must be valid coordinates' });
    }
    Bookings.setLocation(booking.id, lat, lng);
    if (booking.providerId) notifyProvider(booking.providerId, 'location-updated', { bookingId: booking.id });
    return sendJSON(res, 200, { ok: true });
  }

  const trackMatch = pathname.match(/^\/api\/track\/([a-f0-9]{48})$/);
  if (trackMatch && method === 'GET') {
    const booking = Bookings.findByTrackingToken(trackMatch[1]);
    if (!booking) return sendJSON(res, 404, { error: 'This tracking link is invalid.' });
    const customer = Users.findById(booking.userId);
    return sendJSON(res, 200, {
      serviceTitle: booking.serviceTitle,
      address: booking.address,
      status: booking.status,
      customerFirstName: customer ? (customer.name || '').split(' ')[0] : 'Customer',
      sharing: booking.locationSharing,
      location: booking.locationSharing ? booking.location : null,
    });
  }

  // ----- provider jobs (providers only) -----
  if (pathname === '/api/provider/jobs/available' && method === 'GET') {
    const auth = getAuthUser(req, 'provider');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated as a provider' });
    const jobs = Bookings.findAvailableForProvider(auth.user.id);
    return sendJSON(res, 200, { jobs: jobs.map(b => publicBookingForProvider(b, false)) });
  }

  const acceptMatch = pathname.match(/^\/api\/provider\/jobs\/(\d+)\/accept$/);
  if (acceptMatch && method === 'POST') {
    const auth = getAuthUser(req, 'provider');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated as a provider' });
    const bookingId = Number(acceptMatch[1]);
    const existing = Bookings.findById(bookingId);
    if (!existing) return sendJSON(res, 404, { error: 'Job not found' });
    if (!(auth.user.categories || []).includes(existing.serviceKey)) {
      return sendJSON(res, 403, { error: 'This job is outside the services you offer.' });
    }
    // Atomic accept — the WHERE clause inside acceptIfAvailable only matches
    // if still pending & unassigned, so two providers racing for the same
    // job can't both win it.
    const booking = Bookings.acceptIfAvailable(bookingId, auth.user.id);
    if (!booking) {
      const current = Bookings.findById(bookingId);
      return sendJSON(res, current && current.providerId ? 409 : 400, {
        error: current && current.providerId ? 'This job has already been accepted by another provider.' : 'This job is no longer available.',
      });
    }
    notifyCustomer(booking.userId, 'booking-updated', { bookingId: booking.id });
    broadcastToMatchingProviders(booking.serviceKey, 'job-taken', { bookingId: booking.id });
    return sendJSON(res, 200, { job: publicBookingForProvider(booking, true) });
  }

  const releaseMatch = pathname.match(/^\/api\/provider\/jobs\/(\d+)\/release$/);
  if (releaseMatch && method === 'POST') {
    const auth = getAuthUser(req, 'provider');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated as a provider' });
    const bookingId = Number(releaseMatch[1]);
    const existing = Bookings.findById(bookingId);
    if (!existing || existing.providerId !== auth.user.id) return sendJSON(res, 404, { error: 'Job not found' });
    if (['done', 'cancelled'].includes(existing.status)) return sendJSON(res, 400, { error: 'This job can no longer be released.' });
    Bookings.release(bookingId, auth.user.id);
    notifyCustomer(existing.userId, 'booking-updated', { bookingId });
    broadcastToMatchingProviders(existing.serviceKey, 'job-available', { bookingId });
    return sendJSON(res, 200, { ok: true });
  }

  const providerStatusMatch = pathname.match(/^\/api\/provider\/jobs\/(\d+)\/status$/);
  if (providerStatusMatch && method === 'PATCH') {
    const auth = getAuthUser(req, 'provider');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated as a provider' });
    const bookingId = Number(providerStatusMatch[1]);
    const existing = Bookings.findById(bookingId);
    if (!existing || existing.providerId !== auth.user.id) return sendJSON(res, 404, { error: 'Job not found' });
    const body = await readBody(req);
    const VALID_NEXT = { confirmed: 'en_route', en_route: 'done' };
    if (VALID_NEXT[existing.status] !== body.status) {
      return sendJSON(res, 400, { error: `Cannot move from "${existing.status}" to "${body.status}".` });
    }
    const booking = Bookings.setStatus(bookingId, auth.user.id, body.status);
    notifyCustomer(booking.userId, 'booking-updated', { bookingId: booking.id });
    return sendJSON(res, 200, { job: publicBookingForProvider(booking, true) });
  }

  if (pathname === '/api/provider/jobs/mine' && method === 'GET') {
    const auth = getAuthUser(req, 'provider');
    if (!auth) return sendJSON(res, 401, { error: 'Not authenticated as a provider' });
    const jobs = Bookings.findByProvider(auth.user.id);
    return sendJSON(res, 200, { jobs: jobs.map(b => publicBookingForProvider(b, true)) });
  }

  // ----- concierge -----
  if (pathname === '/api/concierge' && method === 'POST') {
    const body = await readBody(req);
    if (!body.message) return sendJSON(res, 400, { error: 'message is required' });
    return sendJSON(res, 200, await conciergeReply(String(body.message)));
  }

  // ----- feedback -----
  if (pathname === '/api/feedback' && method === 'POST') {
    const auth = getAuthUser(req);
    const body = await readBody(req);
    const entry = Feedback.create({ userId: auth ? auth.user.id : null, rating: body.rating || null, message: body.message || '' });
    return sendJSON(res, 201, { feedback: entry });
  }

  // ----- admin (read-only, opt-in via ADMIN_TOKEN env var) -----
  function isAdmin(r) {
    return !!ADMIN_TOKEN && r.headers['x-admin-token'] === ADMIN_TOKEN;
  }
  if (pathname === '/api/admin/overview' && method === 'GET') {
    if (!isAdmin(req)) return sendJSON(res, 404, { error: 'Not found' });
    return sendJSON(res, 200, {
      customers: Users.countByRole('customer'),
      providers: Users.countByRole('provider'),
      bookings: Bookings.all().length,
      activeBookings: Bookings.all().filter(b => ['pending', 'confirmed', 'en_route'].includes(b.status)).length,
      charges: Charges.count(),
      revenueSucceeded: Charges.totalSucceeded(),
      feedbackCount: Feedback.count(),
    });
  }
  if (pathname === '/api/admin/users' && method === 'GET') {
    if (!isAdmin(req)) return sendJSON(res, 404, { error: 'Not found' });
    return sendJSON(res, 200, { users: Users.all().map(publicUser) });
  }
  if (pathname === '/api/admin/bookings' && method === 'GET') {
    if (!isAdmin(req)) return sendJSON(res, 404, { error: 'Not found' });
    return sendJSON(res, 200, { bookings: Bookings.all().map(publicBookingForCustomer) });
  }
  if (pathname === '/api/admin/charges' && method === 'GET') {
    if (!isAdmin(req)) return sendJSON(res, 404, { error: 'Not found' });
    return sendJSON(res, 200, { charges: Charges.all() });
  }
  if (pathname === '/api/admin/feedback' && method === 'GET') {
    if (!isAdmin(req)) return sendJSON(res, 404, { error: 'Not found' });
    return sendJSON(res, 200, { feedback: Feedback.all() });
  }

  // ----- real-time event stream -----
  if (pathname === '/api/events' && method === 'GET') {
    const { query } = url.parse(req.url, true);
    const session = query.token && Sessions.get(query.token);
    if (!session) return sendJSON(res, 401, { error: 'Not authenticated' });
    const user = Users.findById(session.userId);
    if (!user) return sendJSON(res, 401, { error: 'Not authenticated' });

    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write(': connected\n\n');
    const client = { res, userId: user.id, role: user.role, categories: user.categories || [] };
    sseClients.add(client);
    req.on('close', () => sseClients.delete(client));
    return;
  }

  return sendJSON(res, 404, { error: 'Not found' });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer-when-downgrade');
  const { pathname } = url.parse(req.url);
  try {
    if (pathname.startsWith('/api/')) {
      await handleApi(req, res, pathname);
    } else if (pathname.startsWith('/track/')) {
      serveStatic(req, res, '/track.html');
    } else if (pathname === '/provider') {
      serveStatic(req, res, '/provider.html');
    } else if (pathname === '/admin') {
      serveStatic(req, res, '/admin.html');
    } else {
      serveStatic(req, res, pathname);
    }
  } catch (err) {
    console.error(err);
    sendJSON(res, 500, { error: err.message || 'Server error' });
  }
});

server.listen(PORT, () => {
  console.log(`Done app running at http://localhost:${PORT}`);
  console.log(`Provider portal at http://localhost:${PORT}/provider`);
  if (ADMIN_TOKEN) console.log(`Admin dashboard at http://localhost:${PORT}/admin (token configured)`);
  if (!emailConfigured) console.log('SMTP_USER/SMTP_PASS not set — password reset emails will be logged to the console instead of sent.');
  console.log(ANTHROPIC_API_KEY ? 'ANTHROPIC_API_KEY set — AI concierge is using the real Claude API.' : 'ANTHROPIC_API_KEY not set — AI concierge is using keyword matching.');
});
